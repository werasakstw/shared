import java.util.*;
import java.util.function.*;

/* Java 8, forEach() has been added to the Iterable interface,
  which is a super-interface of Collection.
So all Collection objects can be forEach().   */

class ForEach {
	public static void main(String[] args) {
		List<String> a = Arrays.asList("John", "Jack", "Joe");

/* External Iteration: Users define how to iterate with 'for' loop
  and provide action to perform in each iterations.
For iterable object, 'for' loop uses the iterator provided by the object. */
		for(String x : a)
			System.out.print(x + ",");
		System.out.println();

/* Internal Iteration: Users delegate how to iterate to forEach() which is
   a library and provide a functional to be performed in each iterations.
forEach() accepts a consumer lambda and not return a value.  */
		a.forEach(x -> System.out.print(x + ","));
		System.out.println();

/* External iteration concern with 'how' to iterate and 'what' to perform.
Internal iteration concern only with 'what'.

forEach() can optimize iteration performance e.g. laziness, parallelism, 
  and out-of-order execution. None of these is user concern. */

		a.forEach(x -> {
			if (x.equals("Jack"))
				return;
			System.out.println("Hi " + x);
		});
		System.out.println();
/* Using 'return' in forEach() just terminates the current iteration and
  continue the next round. There is no way to terminate the rest iteration. */
	}
}

