import javax.swing.*;
import java.awt.*;
import java.util.*;
class Greet {
	public static void hello() {
		System.out.println("Hello");
	}
}
class RunnableEx {
	public static void test() {
/* Anonymous Class */
		Runnable ano = new Runnable(){
			public void run() {
				Greet.hello();
			}
		};
		new Thread(ano).start();

/* Lambda */
		Runnable lam = () -> Greet.hello();
	   new Thread(lam).start();

/* Method reference */
		new Thread(Greet::hello).start();
	}
}

class ComparatorEx {
	public static void test() {
		String a[] = {"John", "Jack", "Joe", "Jim", "Jame"};

		String a1[] = a.clone();
		Arrays.sort(a1, (x, y) -> x.compareTo(y));
		System.out.println(Arrays.asList(a1));

		String a2[] = a.clone();
		Arrays.sort(a2, String::compareTo);
		System.out.println(Arrays.asList(a2));
	}
}

class ActionListenerEx {
	public static void test() {
		JButton bt = new JButton("Greet");

/* Anonymous class */
	/*	bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Hello!");
			}
		});
	*/

/* Lambda */
		bt.addActionListener(e -> System.out.println("Hi!"));

		JFrame jf = new JFrame("Lambda Listener");
		jf.add(bt, BorderLayout.CENTER);
		jf.pack();
		jf.setVisible(true);
	}
}
class Examples {
	public static void main(String[] args) {
		RunnableEx.test();
		// ComparatorEx.test();
		// ActionListenerEx.test();
	}
}