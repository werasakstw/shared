/* Binding is the process that a name is associated
 with a value. Java performs:
	static binding (at compile time) for data.
	dynamic binding (at runtime) for mrthods.
*/
class A {
	int x = 1;
	String getName() { return "A"; }
}
class B extends A {
	int x = 2;
	String getName() { return "B"; }

	public static void test() {
		A a = new B();
		System.out.println(a.x + "," + a.getName());	// 1, B
	}
}

/* Polymorphism methods accept parameters of certain class or
  its sub-class and behave depend on the input class. */
class PolyMethod {
	static void t(A a) {
		System.out.println(a.getName());
	}
	public static void test() {
		t(new A());
		t(new B());

/* Polymorphism array may have elements of different classes
but have a common ancestor. When apply an operation through
all elements the results vary depend on the element class. */
		A a[] = new A[] { new A(), new B() };
		for (A x : a)
			System.out.print(x.getName() + ", ");
	}
}
//--------------------------------------------------------

/* Example uses of polymorphism:
Unifing classes.  */
class Shape {
	public String getName() { return "unknow"; }
	public double getArea() { return 0.0; }
}
class Rectangle extends Shape {
	private double width, height;
	Rectangle(double width, double height) {
		this.width = width; this.height = height;
	}
	public String getName() { return "rectangle"; }
	public double getArea() { return width * height; }
}
class Triangle extends Shape {
	private double base, height;
	Triangle(double base, double height) {
		this.base = base; this.height = height;
	}
	public String getName() { return "triangle"; }
	public double getArea() { return 0.5 * base * height; }
}
class Unify {
	static void show(Shape s) {
		System.out.println(s.getName() + ": " + s.getArea());
	}
	public static void test() {
		// show(new Shape());
		show(new Rectangle(2,3));
		show(new Triangle(2,3));
	}
}
//----------------------------------------------------------

// PlugIn:
class Driver {
	public void print() { }
}
class Word {
	private Driver d;
	Word(Driver d) { this.d = d; }
	public void setDriver(Driver d) { this.d = d; }
	public void print() { d.print(); }
}
class Epson extends Driver{
	public void print() { System.out.println("Epson"); }
}
class Hp extends Driver{
	public void print() { System.out.println("Hp"); }
}
class PlugIn {
	public static void test() {
		Word w = new Word(new Epson());
		w.print();
		w.setDriver(new Hp());
		w.print();
	}
}

class Polymorphism {
	public static void main(String args[]) {
		// B.test();
		// PolyMethod.test();
		Unify.test();
		PlugIn.test();
	}
}
