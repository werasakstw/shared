/*  Java provides 'super' reference for accessing members
 of the nearest ancestor that are shadowed or overrided. */
class ABC {
	static class A {
		int a = 1;
	}
	static class B extends A {
		int a = 2;
		void print() {
			System.out.println(super.a + "," + this.a);
		}
	}
	static class C extends B {
		int a = 3;
		void print() {
			System.out.println(super.a + "," + this.a);
		}
	}
	public static void test() {
		// new B().print();
		new C().print();		// 2,3
	}
}
//--------------------------------------------------------

/*	Overriding is to replace the method with a new one.
	Extending is to execute the old method and do something extra.
*/
class Extend {
	static class A {
		void f() { System.out.println("A"); }
	}
	static class B extends A { 	// override
		void f() { System.out.println("B"); }
	}
	static class C extends A { 	// extend
		void f() {
			super.f();
			System.out.println("C");
		}
	}
	public static void test() {
		new B().f();
		new C().f();
	}
}
//-----------------------------------------------------

/*  super() is used in sub-class to call the constructor of the super-class.
super() must be the first statement of a constructor and once only.
There will be either this() or super() not both at the first statement.
If the first statement of a constructor has no this() or super(),
  the compiler will give an empty super().   */
class SuperCons {
	static class A {
		A(String s) {System.out.println(s); }
	}
	static class B extends A {
		B() { 
			super("Hello");			// Try: comment this line.
			System.out.println("Hi");
		}
	}
	public static void test() {
		new B();
	}
}

/* There are two ways to make a class non-extensible.
 	- uses the 'final' keyword.
 	- make the class has only private connstructor, but this
	    also make the class not initiatable.  */
class X { private X() { } }
// class Y extends X { }			// error

//--------------------------------------------------------

/* When a constructor of a base class is initiated, all constructors
  of its ancestor classes are executed from top down.  */
class ConsChain {
	static class A {
		A() { super(); System.out.println("A"); }
		A(String c) { super(); System.out.println("A(" + c + ")"); }
	}
	static class B extends A {
		B()  { super("hi"); System.out.println("B"); }
		B(String c) { super(); //super("hello");
		System.out.println("B(" + c + ")"); }
	}

	public static void test() {
		new B();
		// new B("hi");
	}
}
//------------------------------------------------------------

/* We should design the class hierarchy so that:
  1. Only the designated constructor needs to chain upward.
  2. Constructors should initialize only the data that defined
      in its class.
	e.x. Bad
			class A {
				protected int a;
				A() { this(0); }
				A(int a) { this.a = a; }
			}
			class B extends A {
				private int b;
				B(int a, int b) { super(); super.a = a; this.b = b; }
			}
*/
class DesConsChain {
	static class A {
		int x;
		A() { this(0); }
		A(int x) { this.x = x; }
		A(A a) { this(a.x); }
	}
	static class B extends A {
		int y;
		B() { this(0, 0); }
		B(int x, int y) { super(x); this.y = y; }
		B(B b) { this(b.x, b.y); }
	}
}

class Super {
	public static void main(String args[]) {
		ABC.test();
		// Extend.test();
		// SuperCons.test();
		// ConsChain.test();
	}
}
