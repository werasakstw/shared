import com.mypack.C;

/* Visibility must be detremined with class relationship and package.

For Child and parent classes are in the same package. */
class A {
	private int w = 1;
	int x = 2;
	protected int y = 3;
	public int z = 4;
	static int s = 5;

	int get_W() { return w; }
}
class B extends A {
	public void f() {
/* Private members are inherited but not accessible. */
		// System.out.println(w);			//error
		System.out.println(get_W());	

/* Non-private and static member are inherited. */
		System.out.println(x + ", " + y + ", " + z + ", " + s);
	}
}
//-------------------------------------------------------

class SubClassOtherPack extends C {
	public void print() {
		System.out.println(x3 + x4);
	}
}

class OtherClassOtherPack {
	public void print() {
		C c = new C();
		System.out.println(c.x4);
	}
}

/*					Visibility Modifiers
									private		defaul	protected	 public
Same Class Same Package		   yes		 yes		  yes			  yes
Sub Class Same Package		   no		 	yes		  yes			  yes
Other Class Same Package	   no		 	yes		  yes			  yes
Sub Class Other Package	  	   no		  	no		  	  yes			  yes
Other Class Other Package	   no		  	no		     no			  yes
*/
