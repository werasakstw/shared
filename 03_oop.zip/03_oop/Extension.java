/* Code reuse may be done with:
	- composition
	- extension				*/
class A {
	public void f() { System.out.println("A.f"); 	}
	public void g() { System.out.println("A.g"); 	}
	// public voi g() { return 1; 	}
}

/* Composition:
 C is a user of class 'A'.*/
class C {
	private A a = new A();
	public void f() { a.f(); }	// forwarding
	public void g() { System.out.println("C.g"); }
}

/* Extension is a mechanism to create a child class for a parent class.
			class <child> extends <parent> { <body> }
<child> class inherits <parent> members.
E is a child of class 'A'. */
class E extends A { 
	@Override
	public void g() { System.out.println("E.g"); }
}

class ReUse {
	public static void main(String args[]) {
		C c = new C(); 
		c.f(); c.g();
		E e = new E(); 
		e.f(); e.g();
	}
}
