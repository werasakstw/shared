import bitcoin as bc

# 'bitcoin' lib provides a constant N for the max value of private key.
# A private keys is a non-negative interger that less than bitcoin.N.
# Normally private keys are represented as hex string.
# Bitcoin private keys are 64 hex-digits (32 bytes).
def max_prikey():
    print(bc.N)
    # 115792089237316195423570985008687907852837564279074904382605163141518161494337
    n_hex = hex(bc.N)[2:]  # exclude prefix '0x'.
    print(len(n_hex), n_hex)
    # 64 fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
# max_prikey()

## Private key verification:
def is_valid_privkey(k):  # 'k' is an int.
    return 0 < k < bc.N

# 'bitcoin' lib provides is_privkey(), is_pubkey() and is_address().
# print(bc.is_privkey(bc.N))        # True

## Generate private keys:
import random
seed = 'This is a seed.'
def private_key():
    # Generate private key randomly.
    for _ in range(3):
        print(hex(random.randint(1, bc.N))[2:])
    print()

    # bc.sha256(<seed>) results value with a slim chance of
    # overflow the value of bc.N. But allows repeatedly creating
    # the same values from a <seed>.
    for _ in range(3):
        print(bc.sha256(seed))
    print()

    # bc.random_key() results a random valid private key.
    for _ in range(3):
        print(bc.random_key())
private_key()

## Compressed private key verification:
# Uncompressed private keys are 32 bytes (64 hex-digits).
# Compressed private keys are 33 bytes (66 hex-digits) and ends with '01'.
def is_compressed_privkey(k):   # 'k' is a str.
    return bc.is_privkey(k) and k.endswith('01')

# Private key encodes:
def privkey_encode():
    hex_str = bc.sha256(seed)
    print(hex_str)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # From hex string to byte array
    byte_array = bc.from_string_to_bytes(hex_str)
    print(byte_array)
    # b'517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86'

    # From hex str to (decimal)int, so that arithmetic can be performed
    dec_int = bc.decode_privkey(hex_str, 'hex')
    print(dec_int)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    # From (decimal)int to hex str.
    print(bc.encode_privkey(dec_int, 'hex'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # From (decimal)int to hex str in compressed format private key.
    print(bc.encode_privkey(dec_int, 'hex_compressed'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    # From (decimal)int to hex str in wif format private key.
    pw = bc.encode_privkey(dec_int, 'wif')
    print(pw)
    # 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7
    print(bc.decode_privkey(pw, 'wif'))
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    # From (decimal)int to hex str in wif format compressed private key.
    pwc = bc.encode_privkey(dec_int, 'wif_compressed')
    print(pwc)
    # Kyx8qCKsSbUrUxQMaQNsq4rxq23FxkfE2haXgNArX9c38qmpkmG5
    print(bc.decode_privkey(pwc, 'wif_compressed'))
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030
# privkey_encode()
