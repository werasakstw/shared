from eth_utils import keccak, decode_hex
from eth_utils.curried import to_hex
# https://pypi.org/project/eth-utils/1.1.2/

# pip install eth-keys
from eth_keys import keys

## Create Off Wallet Account(owa) and offline.
seed = '1234'
def private_keys():
    # Create a private key form 32 bytes string seed.
    b32 = (seed*8).encode()
    prikey = keys.PrivateKey(b32)
    print(prikey)
    # 0x3132333431323334313233343132333431323334313233343132333431323334

    # Create a private key from vary langth seed.
    # keccak() always return a 32 bytes hash.
    prikey = keys.PrivateKey(keccak(seed.encode()))
    print(prikey)
    # 0x387a8233c96e1fc0ad5e284353276177af2186e7afa85296f106336e376669f7

    # private key -> public key.
    pubkey = prikey.public_key
    print(pubkey)
    # 0x8735526a6028e716da0ec15d1b991d71ce0b156ef4c79f208175f9305fa03a27cb618dbd4d19eddcd6671c3add3f61fcc96ba692e3fb3f271dda5d2251d53115

    # public key -> address.
    print(pubkey.to_address())
    # 0xb8c059e31bcfa20b961d3f5a021b5c44d7da57ae
    print(pubkey.to_checksum_address())
    # 0xb8C059E31BcFa20B961d3F5A021b5C44d7DA57AE
# private_keys()
## Check below: Ethereum Address Formats

## Alternatvely: Create owa using 'eth_account'.
# pip install eth_account
from eth_account import Account
def create_account():
    a = Account.create()        # randomly
    print(to_hex(a.key))        # hex str private key
    print(a.address)            # checksum address
# create_account()

from myutil import *
# Create owa using provider:
# Most providers: Geth, Openethereum, Infura, Anvil and Ganache
# provide service for creating owa.
def create_owa():
    # Infura
    a = w3i.eth.account.create(seed)
    print(to_hex(a._private_key))
    print(a._address)
    print(w3i.eth.accounts)         # []

    # Geth, Openethereum, Anvil, Ganache
    a = w3.eth.account.create(seed)
    print(to_hex(a._private_key))
    print(a._address)
    print(w3.eth.accounts)         # []
# create_owa()

# Openethereum and Ganache supports creating iwa via rpc
# Infura, Geth and Anvil do not.
# print(w3.geth.personal.new_account('john')) # 'john' is password.

# Openethereum stores (iwa) keyfile at data dir.
data_dir = 'C:/Users/THAIMART/AppData/Roaming/OpenEthereum/keys/rinkeby/'
# 'C:/Users/THAIMART/AppData/Local/Ethereum/rinkeby/keystore'
key_file = 'UTC--2022-07-05T03-23-19Z--e65b37bb-4bf6-9c00-34c4-c425a85772f2'

# Retrieving private key from keyfile.
# To decrypt a keyfile we need the key's password.
from web3.auto import w3
def get_privatekey(pwd):
    with open(data_dir+key_file) as f:
        k = w3.eth.account.decrypt(f.read(), pwd)
        print(to_hex(k))
# get_privatekey('john')
# So iwa is not really safe.
# We better use owa and manage private key security.

#--------------------------------------------------------

## Pickling Private Keys in file:
john_prikey = '0xadbbab5c9f62b10d4bcdb3b102f29fe3fa644389e796f60155bf809cd84d9f9b'
jack_prikey = '0x5273729e45021f0b2545678e300792381a6878e1f4de94ddb8e6fd02a8427462'

import pickle
def pickle_prikey():
    d = {'john': john_prikey, 'jack': jack_prikey}
    ## Write to file.
    with open('key', 'wb') as f:
        pickle.dump(d, f)

    ## Read from file.
    with open('key', 'rb') as f:
        rd = pickle.load(f)
    print('john_prikey:', rd['john'])
    print('jack_prikey:', rd['jack'])
# pickle_prikey()

#---------------------------------------------------------------

# Account creating via rpc is discourage.
# Openethereum(fromer Parity) supports json_rpc for account management.
# Ganache does not.

## Create an iwa.
#  The 'recovery phrase' is used for recover pwd and must be unique.
# print_result(rpc('parity_newAccountFromPhrase', quote2('recovery phrase1', 'jack')))
# print_result(rpc('parity_newAccountFromPhrase', quote2('recovery phrase2', 'joe')))

## List accounts with info.
# print(w3.eth.accounts)
# print_json_str(rpc('parity_allAccountsInfo', []))
john_addr = '0x286d11a733ae3c67d7a7b04a438b967abb7a466d'
jack_addr = '0x000a9727ddfe97e01769ac4c1f8e338a1c7c4c1d'

## Verify address with password.
# print_result(rpc('parity_testPassword', quote2(john_addr, 'john')))

## Change password.
old_pwd = 'john'
new_pwd = 'John'
# print_result(rpc('parity_changePassword', quote3(john_addr, old_pwd, new_pwd)))
# print_result(rpc('parity_testPassword', quote2(john_addr, 'john')))
# print_result(rpc('parity_testPassword', quote2(john_addr, 'John')))

# Set account name.
# print_json_str(rpc('parity_setAccountName', quote2(jack_addr, 'Ripper')))
# print_json_str(rpc('parity_allAccountsInfo', []))

# Set account meta (as a json).
# params = '''[\"0x00d6ffa36000c6d01577ab1954e6d4040e20a5bb\", \  # john_addr
# \"{\\"aliases\\":\\"First Blood\\"}\" ]'''
# print_json(rpc('parity_setAccountMeta', params))
# print_json_str(rpc('parity_allAccountsInfo', []))

## Kill an account.
# print_json_str(rpc('parity_killAccount', quote2(john_addr, new_pwd)))
# print(rpc('parity_allAccountsInfo', []))

#-----------------------------------------------------

# Instead of encrypt account manually, Account provides off-wallet encrypt().
def encrypt_account():
    john_acc = Account.create('john')  # 'john' is not the account password.
    print(to_hex(john_acc.key))
    print(john_acc.address)

    # Encrypt an account to a json(dict).
    enc_john_acc = john_acc.encrypt('hello')   # 'hello' is the password.
##    pp.pprint(enc_john_acc)

    # Decrypt an encrypted account to private key
    john_prikey = Account.decrypt(enc_john_acc, 'hello')
    print(to_hex(john_prikey))

    # Retrieve account from private key.
    ja = Account.from_key(john_prikey)
    print(ja.address)
# encrypt_account()

# Instead of encrypt an account, we can just encrypt a private key.
def encrypt_prikey():
    john_acc = Account.create('john')
    john_prikey = john_acc.key
    print(to_hex(john_prikey))

    # Encrypt private key with a password.
    en_john_prikey = Account.encrypt(john_prikey, 'rambo') # 'rambo' is the password.
##    pp.pprint(en_john_prikey)

    # Decrypt the encrypted private key with the password.
    pri = Account.decrypt(en_john_prikey, 'rambo')
    print(to_hex(pri))
# encrypt_prikey()

######################################################

## Ethereum Address Formats:
unpad =   'd3cda913deb6f67967b99d67acdfa1712c293601'
lower = '0xd3cda913deb6f67967b99d67acdfa1712c293601'
upper = '0xD3CDA913DEB6F67967B99D67ACDFA1712C293601'
chsum = '0xd3CdA913deB6f67967B99D67aCDFa1712C293601'

def valid_test():
    ## An Ethereum address is 20 byte hexadecimal, lower/upper/mixed case,
    #   with or without 0x prefix.
    print(is_address(unpad), is_hex_address(unpad)) # True True
    print(is_address(lower), is_hex_address(lower)) # True True
    print(is_address(upper), is_hex_address(upper)) # True True
    print(is_address(chsum), is_hex_address(chsum)) # True True

    # Checksummed address: ERC55
    print(is_checksum_address(unpad))   # False
    print(is_checksum_address(lower))   # False
    print(is_checksum_address(upper))   # False
    print(is_checksum_address(chsum))   # True

    # Normalized addresses are lowercased.
    print(is_normalized_address(lower))    # True
    print(is_normalized_address(upper))    # False
    print(is_normalized_address(chsum))    # False

    # True if both are valid by is_address() and represent the same.
    print(is_same_address(unpad, chsum))    # True
    print(is_same_address(lower, chsum))    # True
    print(is_same_address(upper, chsum))    # True
# valid_test()

def converse_address():
    # Canonical addresses are arrays of bytes, that exactly be handled by programs.
    print(to_canonical_address(unpad))  # b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'
    print(to_canonical_address(lower))
    print(to_canonical_address(upper))
    print(to_canonical_address(chsum))

    print(to_checksum_address(unpad))   # 0xd3CdA913deB6f67967B99D67aCDFa1712C293601
    print(to_checksum_address(lower))
    print(to_checksum_address(upper))
    print(to_checksum_address(chsum))
    print(to_checksum_address(b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'))

    print(to_normalized_address(unpad))   # 0xd3cda913deb6f67967b99d67acdfa1712c293601
    print(to_normalized_address(lower))
    print(to_normalized_address(upper))
    print(to_normalized_address(chsum))
    print(to_normalized_address(b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'))
# converse_address()
