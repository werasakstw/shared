import bitcoin as bc

# Even the compressed version, public keys are big.
# Bitcoin introduced address as the shorter version of public key,
#  and more human-oriented.
seed = 'This is a seed.'
def addresses():
    pri_key = bc.sha256(seed)
    comp_pri_key = pri_key + '01'

    addr = bc.privkey_to_address(pri_key)
    print(addr)         # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2

    comp_addr = bc.privkey_to_address(comp_pri_key)
    print(comp_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA

    # There is also bc.pubkey_to_address().
    pub_key = bc.privkey_to_pubkey(pri_key)
    addr = bc.pubkey_to_address(pub_key)
    print(addr)         # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2

    comp_pub_key = bc.privkey_to_pubkey(comp_pri_key)
    comp_addr = bc.pubkey_to_address(comp_pub_key)
    print(comp_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA
# addresses()

## Private key and Address encode.
def encodes():
    pri_key = bc.sha256(seed) # hex str
    print(pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # from hex string to byte array
    ba_pri_key = bc.from_string_to_bytes(pri_key)
    print(ba_pri_key)
    # b'517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86'

    # from hex string to int (binary but presented as decimal)
    # so that arithmetic can be performed.
    int_pri_key = bc.decode_privkey(pri_key, 'hex')
    print(int_pri_key)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    ## encoded private key from int
    print(bc.encode_privkey(int_pri_key, 'hex'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86
    print(bc.encode_privkey(int_pri_key, 'hex_compressed'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    wif_prikey = bc.encode_privkey(int_pri_key, 'wif')
    print(wif_prikey)
    # 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7

    comp_wif_prikey = bc.encode_privkey(int_pri_key, 'wif_compressed')
    print(comp_wif_prikey)
    # Kyx8qCKsSbUrUxQMaQNsq4rxq23FxkfE2haXgNArX9c38qmpkmG5

    # wif address from private key
    wif_addr = bc.privkey_to_address(wif_prikey)
    print(wif_addr)    # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2

    comp_wif_addr = bc.privkey_to_address(comp_wif_prikey)
    print(comp_wif_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA
# encodes()

#------------------------------------------------------

## To verify fund receiver:
# Suppose John send a transaction transfers BTC to Jack.
# The transaction specifies the fund receiver by Jack address.
# To redeem the transaction Jack must create a transaction that
#   contains his public key to indicate that he is rightful receiver.

## To verify that a public key is the valid reciver of an address:
def is_valid_receiver(pubkey, addr):
    return addr == bc.pubkey_to_address(pubkey)
