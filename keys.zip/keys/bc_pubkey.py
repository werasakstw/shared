import bitcoin as bc

# A public key can be computed from its corresponding private key,
#  but the reverse is infeasible.
# A public key is computed by:
#           <public key>  =  G * <private key>
#    where * is the 'fast multiply', not a mutiplication.

# G is a constant point(x, y) on Elliptic Curve, represented as a tuple.
# print(bc.G)

# Bitcoin public keys is 130 hex-digits (65 bytes).
seed = 'This is a seed.'
def public_key():
    # Generate a private key from a seed.
    hex_priv = bc.sha256(seed)
    print(hex_priv)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # Decoded hex private key to decimal.
    dec_priv = bc.decode_privkey(hex_priv, 'hex')
    print(dec_priv)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    # Public Key is a Point (x,y) on Elliptic Curve of equation:
    #               y**2 mod p = (x**3 + 7) mod p
    #    fast_multiply() is EC multiply.
    pub_point = bc.fast_multiply(bc.G, dec_priv)
    print(pub_point)   # tuple of x and y.
    # (72586088254300629282474542646364941725084793931958144488404839039713232267068, 84543921150964833926999570811767834131266370888940557583189318793530522725677)

    # A public key is the Public Key Point (x,y) encoded to hex.
    # Encode decimal private key to hex string.
    hex_pub = bc.encode_pubkey(pub_point, 'hex')
    print(hex_pub)
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d

    # 'bitcoin' lib provides functions to compute public key from private key.
    print(bc.privkey_to_pubkey(hex_priv))   # Alternatively: bc.privtopub()
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d
# public_key()
# Try: changing the seed. Bitcoin public keys are prefixed with '04'.
# Check with:   bitaddress.org

## Key Compreesion:
# Public keys are too big.
# Since the Elliptic Curve function: y**2 mod p = (x**3 + 7) mod p
#   is known, the x or y part of a point(x, y) can be computed if
#   the other part is known.
# The left side of the equation is y**2 so y may be positive
#   or negative depended on y is even or odd.
# A prefix is used to indicate whether y is even or odd.
def compressed_pubkey():
    hex_priv = bc.sha256(seed)
    dec_priv = bc.decode_privkey(hex_priv, 'hex')
    x, y = bc.fast_multiply(bc.G, dec_priv)
    prefix = '02' if (y % 2) == 0 else '03'
    # Compressed Public Key(hex) is prefix + hex(x)
    print(prefix + bc.encode(x, 16))
    # 03a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73c
# compressed_pubkey()

# So we can store only the x part of a public key, which is called compressed
# public keys that use less space and thus reduce the size of transactions.
# We need a way to distinguish the compresses and un-compressed computations.
#       uncompressed private key -> uncompressed public key
#       compressed private key -> compressed public key
def compressed():
    # Uncompressed private key:
    pri_key = bc.sha256(seed)
    print(pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # Compressed private key:
    # Adding '01' suffix to indicate it is a compressed private key.
    comp_pri_key = pri_key + '01'
    print(comp_pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    # Uncompressed public key: computed from uncompressed private key.
    pub_key = bc.privkey_to_pubkey(pri_key)
    print(pub_key)
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d

    # Compressed public key: computed from compressed private key.
    comp_pub_key = bc.privkey_to_pubkey(comp_pri_key)
    print(comp_pub_key)
    # 03a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73c
# compressed()
