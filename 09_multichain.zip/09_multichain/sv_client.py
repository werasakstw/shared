from myutil import *

r = api.getinfo()    ## dict
pp.pprint(r)

# for (k,v) in r.items():
#      print(k ,': ', v)

