/* Tightly Coupling means a caller and its callee is permanently fixed, 
  changing needs recompilation. */
class TightlyCoupling {
	static class A {
		public void f() { System.out.println("A.f()"); }
	}
	public static void test() {
		A a = new A();
		a.f();
	}
}

/* Decoupling with Interface:
  1. Create an interface with all the methods called by the user.
  2. Make the usee class implements the interface.
  3. In the user class, replace all the references to the usee
       with the references to the interface.   */
interface I { void f(); }
class A implements I {
	public void f() { System.out.println("A.f"); }
}
class B implements I {
	public void f() { System.out.println("B.f"); }
}
class Decoupling {
	public static void test() {
		I i = new A();  	 // new B();
		i.f();
	}
}

/* Create instance with factory. */
class Factory {
	abstract class IFactory {
		public static I getInstance(String name){
			return name.equals("A")? new A() :
					name.equals("B")? new B() : null;
		}
	}
	public static void test() {
		I i = IFactory.getInstance("A");
		i.f();
		i = IFactory.getInstance("B");
		i.f();
	}
}

/* Create instance with Class Object newInstance(). */
class NewInstance {
	abstract class IFactory {
		public static I getInstance(String name) throws ClassNotFoundException,
				IllegalAccessException, InstantiationException {
			return (I) Class.forName(name).newInstance();
		}
	}

	public static void test() {
		try {
			I i = IFactory.getInstance("A");
			i.f();
			i = IFactory.getInstance("B");
			i.f();
		} catch(Exception e) {
			System.out.println(e);
		}
	}
}

class DeCoupling {
	public static void main(String args[]) {
		TightlyCoupling.test();
		// Decoupling.test();
		// Factory.test();
		// NewInstance.test();
	}
}