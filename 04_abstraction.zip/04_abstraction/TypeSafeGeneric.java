import java.util.*;

/* 'Type safe generic' allows checking type errors at compile time. 
Java adopted 'type parameter' for classes and methods to specify 
  the type tobehandled.

1. Type safe generic class.
			<class>< <type parameter> > { <body> }			 */
class GenericClass {
	static class A<T> {		// T is a type parameter to class 'A'.
		T t;
		A(T t) { this.t = t; }
		public T getT() { return t; }
		public void setT(T t) { this.t = t; }
	}

/* Type parameters must be initiated before used. */
	public static void test() {
		A<Integer> a1 = new A<Integer>(1);
		A<String> a2 = new A<String>("Hello");
		System.out.println(a1.getT() + ", " + a2.getT());	// 1 Hello
		// a1.setT("1");			// compiler time error
		// a1 = a2;					// compiler time error
	}
/* Restriction:
	T t;					// Define reference of type T.
	T getT() { return t; }	// Return type of T.
	// T t = new T(); 		// cannot be instantiated.
	// static T t;			// cannot be static.
	T a[];					// It's ok to define array of type T.
	// a = new T[10];		// But cannot create an array of type T.*/
}

/* 2. Type safe generic method.
The type parameters are defined before the return type, but after modifiers.
So that they can be used in the method parameters. */
class GenericMethod {
	static <T, S extends T> boolean isMember(T t, S s[]) {
		for(int i = 0; i < s.length; i++)
			if(t.equals(s[i]))
				return true;
		return false;
	}
	public static void test() {
		Integer a[] = {1,2,3,4,5};
		System.out.println(isMember(2, a));		// true

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		System.out.println(isMember(7.0, d));	// false
	}
}

/* To simplify type safe generic collection defintions. */
class DiamondOp {
	public static void test() {
/* Pre-Java7: Implicit type is allowed but warned, default is <Object>. */
		// List c = new ArrayList<String>();	// warned:
		// List<String> x = new ArrayList();	// warned:

/* Pre-Java7: both left and right hand sides must be explicit typed.  */
		List<String> a = new ArrayList<String>();
		a.add("Helo");

/* Java 7 introduces <>, diamond operator, it allows type inference,
     no need to repeat the type parameter. */
		List<String> b = new ArrayList<>();   // Try: remove <>.
		b.add("Hi");

/* Java 9 allows anonymous class with diamond operator. */
		List<String> l = new ArrayList<>(){ };
	}
}

/* Type Inference with Wildcard:
When a type parameter can be inferred from assigned or passed value, 
  it is allowed to use a wildcard ? for specify any types. */
class WildcardArg {
	static class MyArray<T extends Number> {
		private T t[];
		MyArray(T t[]) { this.t = t; }
		public double average() {
			double s = 0.0;
			for (T x : t)
				s += x.doubleValue();
			return s / t.length;
		}
		boolean sameAvg(MyArray<?> a) {
			return (average() == a.average())? true : false;
		}
	}
	public static void test() {
		Integer i[] = {1,2,3,4,5};
		MyArray<?> a = new MyArray<>(i);
		System.out.println(a.average());

		Double d[] = {1.0, 2.0, 3.0, 4.0, 5.0};
		MyArray<?> b = new MyArray<>(d);
		System.out.println(b.average());

		System.out.println(a.sameAvg(b));
	}
}

/* Bound Generic:
A type parameter can be bound to a super class which allows family of classes.  */
class BoundGeneric {
	static class X { }
	static class A extends X { }
	static class B extends X { }
	static class C { }
	static class G<T extends X> {
		private T t;
		G(T t) { this.t = t; }
		public T getT() { return t; }
		public void setT(T t) { this.t = t; }
	}
	public static void test() {
		G<X> g = new G<>(new X());
		g.setT(new A());
		g.setT(new B());
		// g.setT(new C());			// error
	}
}

class TypeSafeGeneric {
	public static void main(String args[]) {
		// GenericClass.test();
		// GenericMethod.test();
		// DiamondOp.test();
		// WildcardArg.test();
		BoundGeneric.test();
	}
}