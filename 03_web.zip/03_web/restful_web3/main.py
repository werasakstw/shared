from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# URL = 'http://127.0.0.1:8545'
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"

from web3 import Web3
w3 = Web3(Web3.HTTPProvider(URL))
from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

@app.route('/getversion')
def get_version():
   return w3.clientVersion

@app.route('/getbalance', methods=['POST'])
def get_balance():
   addr = request.form.get('addr')
   return str(w3.eth.getBalance(addr))

@app.route('/getgasprice')
def get_gasprice():
   return str(w3.eth.gasPrice)

if __name__ == '__main__':
    app.run(port=8080, debug=True)