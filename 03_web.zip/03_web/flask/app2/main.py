from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

import requests
# URL = 'http://127.0.0.1:8545'
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}
def jsonrpc_request(method, param):
    DATA = '{"jsonrpc":"2.0", "method": "%s","params": %s, "id": 1}' % (method, param)
    return requests.post(URL, data=DATA, headers=HEADERS).text

import json
@app.route('/getversion_curl')
def get_version_curl():
   res = json.loads(jsonrpc_request('web3_clientVersion', []))
   return res['result']

from web3 import Web3
w3 = Web3(Web3.HTTPProvider(URL))
from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

@app.route('/getversion_web3py')
def get_version_web3py():
   return w3.clientVersion

if __name__ == '__main__':
    app.run(port=8080, debug=True)