# pip install flask

from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
# http://127.0.0.1:8080
# curl 127.0.0.1:8080

@app.route('/hello')
def hello():
    return 'Hello how are you?'
# http://127.0.0.1:8080/hello
# curl 127.0.0.1:8080/hello
# curl -verbose 127.0.0.1:8080/hello

# Path Parameters:
@app.route('/add/<a>/<b>')
def do_add(a, b):
    return str(int(a) + int(b))
# http://127.0.0.1:8080/add/1/2
# curl 127.0.0.1:8080/add/3/4

# Query String:
@app.route('/sub')
def do_sub():
    a = request.args['a']         # error 400 if no 'a'.
    b = request.args.get('b')     # None if no 'b'.
    return str(int(a) - int(b))
# http://127.0.0.1:8080/sub?a=1&b=2
# curl 127.0.0.1:8080/sub?"a=2&b=1"    Query string must be double quoted.

# Form GET parameters are passed as query string.
@app.route('/mul')
def do_mul():
    a = request.args['a']
    b = request.args.get('b')
    return str(int(a) * int(b))
# http://127.0.0.1:8080/mul?a=2&b=3
# curl 127.0.0.1:8080/mul?"a=2&b=3"

# Form POST parameters are passed as 'data' of the request.
@app.route('/div', methods=['POST'])
def do_div(): 
    a = request.form['a']
    b = request.form.get('b')
    return str(float(a) / float(b))
# curl 127.0.0.1:8080/div -X POST -d "a=4&b=2"


if __name__ == '__main__':
    app.run(port=8080, debug=True)  # http://127.0.0.1:8080
##    app.run()	   	            # http://127.0.0.1:5000

'''  app.run(host, port, debug)
host: Defaults is 127.0.0.1 (localhost). 
port: Defaults is 5000.
debug: Defaults is False.
'''


