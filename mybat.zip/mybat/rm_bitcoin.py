import shutil
try:
	shutil.rmtree('C:/Users/THAIMART/AppData/Roaming/Bitcoin')
except OSError as e:
        print(e)
print('Delete success.')