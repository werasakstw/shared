import shutil
try:
	shutil.rmtree('C:/Users/THAIMART/AppData/Local/Ethereum')
except OSError as e:
        print(e)
print('Delete success.')