import shutil
try:
	shutil.rmtree('C:/Users/THAIMART/AppData/Local/OpenEthereum')
	shutil.rmtree('C:/Users/THAIMART/AppData/Roaming/OpenEthereum')
except OSError as e:
        print(e)
print('Delete success.')