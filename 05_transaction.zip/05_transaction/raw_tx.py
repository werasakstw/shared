from web3 import Web3
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
john_addr = "0x883F0830B40cA38E2febF207cf6f1f7b912D56C9"
# print(w3.eth.get_balance(me_addr))
# print(w3.eth.get_balance(john_addr))

def get_nonce_currGas(addr):
    nonce = w3.eth.getTransactionCount(addr)
    block = w3.eth.getBlock("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return nonce, currGas
# print(get_nonce_currGas(me_addr))

# 'nonce' is used for prevent sending a tx more than once,
#    mostly it is the number of tx sent by the address.
# 'chainId' is used for prevent sending tx acorss chains.
# 'gas' is the max gas allowed to execute this tx,
#    the minimum is 0x21000.
# 'gasPrice' is the price offered by the sender, mostly
#    obtained from the last block, but may not enough in bussy hours.
# 'form' is the sender address that already included in the tx sig.

from eth_utils.curried import to_hex
# Send from 'me' to 'john' using raw tx.
def send_raw_tx():
    nonce, currGas = get_nonce_currGas(me_addr);
    tx = {   # A dict
        'to': john_addr,    # receiver address
        'value': w3.toWei("0.000001", "ether"),     # in wei
        'nonce': nonce,
        'chainId': "0x4",   # EIP-155 requires chainId.
        'gas': "0x21000",
        'gasPrice': currGas,    # "0x40000000",
    }               # Sometime currGas is not enough.
    # print(tx)

    # Sign transaction with sender private key.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)

    # Send the transaction
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# send_raw_tx()
tx_hash = '0xb968ad07055f4511dace1343d5673226591c31c064a6e568be4117ef285b1bc0'

# The tx is sent but may not success.
# Check the tx sent by this address in Etherscan.
# Wait while pending until transfer.
# Check tx:
# print_json(w3.eth.get_transaction(tx_hash))
# print_json(w3.eth.get_transaction_receipt(tx_hash))
# The success tx "transactionIndex" should not be null.
# Try: 'john' balance again.
