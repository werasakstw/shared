## Bitcoin Sign and Verify:
import bitcoin as bc
def bc_authen():
    msg = 'Hello, how are you today?'
    prikey = bc.random_key()
    pubkey = bc.privkey_to_pubkey(prikey)

    # Sign: message + private_key --> signature
    sig = bc.ecdsa_sign(msg, prikey)   # base64
    print('signature:', sig)

    ## Try: Verify with non-correspond public key.
    # pubkey = bc.privkey_to_pubkey(bc.random_key())

    ## Try: Data was modified.
    # msg = 'Hello, how are you today.'

    # Verify: message + signature + public_key --> boolean
    print('Verify:', bc.ecdsa_verify(msg, sig, pubkey))
# bc_authen()

#--------------------------------------------------------

from eth_account.messages import encode_defunct
from eth_utils.curried import to_hex, to_bytes
from eth_account import Account
def eth_sign():
    a = Account.create()
    print(to_hex(a.key))
    print(a.address)

    ## The message to be signed must be a signable message (EIP-191).
    msg = 'Hello how do you do?'
    signable_msg = encode_defunct(text=msg)
    # print(signable_msg.body)

    ## Sign message with the signer's private key
    signed_msg = Account.sign_message(signable_msg, a.key)
    # print(signed_msg)

    ## A signed message contains its signature.
    sig = signed_msg.signature
    print(to_hex(sig))

    # Recover the signer address from msg and sig.
    ac = Account.recover_message(encode_defunct(text=msg), \
                                 signature=sig)
    print(ac)

    # A signed message also contains its message hash
    #  which is using less space than the message.
    msg_hash = signed_msg.messageHash
    print(to_hex(msg_hash))

    # Alternatively we can recover the signer address
    #  from its message hash instead of the message.
    ac = Account.recoverHash(msg_hash, signature=sig)
    print(ac)
# eth_sign()

def eth_authen():
    a = Account.create()
    msg = 'Hello how do you do?'
    signable_msg = encode_defunct(text=msg)

    ## Sign:
    signed_msg = Account.sign_message(signable_msg, a.key)

    ## Verify:
    addr = Account.recover_message(signable_msg, \
                     signature=signed_msg.signature)
    print(a.address == addr)

    ## Try: The message was tampered.
    # msg = 'Hello how do you do.'
    # addr = Account.recover_message(encode_defunct(text=msg), \
    #                  signature=signed_msg.signature)
    # print(a.address == addr)

    ## Try: The message was signed with non-correspond private key.
    # signed_msg = Account.sign_message(signable_msg,
    #                  Account.create('jack').key)
    # addr = Account.recover_message(signable_msg, \
    #                  signature=signed_msg.signature)
    # print(a.address == addr)
# eth_authen()
