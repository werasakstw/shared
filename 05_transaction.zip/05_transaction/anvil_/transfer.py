from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

## Anvil start screen shows lower addresses.
a1 = '0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266'
a2 = '0x70997970c51812dc3a010c7d01b50e0d17dc79c8'

## web3.py needs checksummed addresses.
from eth_utils import *
a1 = to_checksum_address(a1)
a2 = to_checksum_address(a2)
def check_balances():
    print('a1:', w3.eth.getBalance(a1))
    print('a2:', w3.eth.getBalance(a2))
# check_balances()

# from eth_utils.curried import to_hex
def send_tx():
    tx = { 'from': a1, 'to': a2, 'value': 1 }
    print(w3.toHex(w3.eth.sendTransaction(tx)))
# send_tx()
tx_hash = '0xca36ae41b44b88486c0c9aa1d0e0a3875d40c1afff2a351a17c1de600d29ed8c'

## Get tx info by tx_hash.
def tx_info():
    tx = w3.eth.get_transaction(tx_hash)
    # print_json(tx)
    print('to:', tx['to'])
    print('value:', tx['value'])
    print('gas:', tx['gas'])
    print('gasPrice:', tx['gasPrice'])
    print('nonce:', tx['nonce'])
# tx_info()
