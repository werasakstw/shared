from web3 import Web3
url = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(url))

# print(w3.clientVersion)
# print(w3.eth.chainId)
# print(w3.eth.blockNumber)
# print(w3.eth.gasPrice)

for a in w3.eth.accounts:
    print(a, w3.eth.getBalance(a))
