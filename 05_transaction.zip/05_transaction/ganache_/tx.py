from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

def info():
    print(w3.clientVersion)
    print(w3.eth.chainId)
    print(w3.eth.blockNumber)
    print(w3.eth.gasPrice)
    for a in w3.eth.accounts:
        print(a, w3.eth.getBalance(a))
# info()

a1 = "0x508d3b84d1E8a1db2941C17755a2f8C0870F38A4"
a2 = "0xe333A1b9659a1385b0E7484d0416643105D96697"
a1_prikey = "84751db8a83f8edd195fa71a9515d7af5d87c2aaf49eecfbdd8bb756a66e093d"
def balances():
    print(w3.eth.get_balance(a1))
    print(w3.eth.get_balance(a2))
# balances()

def get_nonce_currGas(addr):
    nonce = w3.eth.getTransactionCount(addr)
    block = w3.eth.getBlock("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return nonce, currGas
# print(get_nonce_currGas(a1))

from eth_utils.curried import to_hex
# Send from a1 to a2 using raw tx.
def send_raw_tx():
    nonce, currGas = get_nonce_currGas(a1);
    tx = {
        'to': a2,
        'value': w3.toWei("0.000001", "ether"),     # in wei
        'nonce': nonce,
        'chainId': "0x4",
        'gas': "0x21000",
        'gasPrice': currGas,
    }
    # print(tx)

    # Sign transaction with sender private key.
    signed_tx = w3.eth.account.sign_transaction(tx, a1_prikey)

    # Send the transaction
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# send_raw_tx()
# balances()
tx_hash = '0x2266eada943d2c14a705bed43be4837c89fcf1c933fff5de0ebd0851fa049ef5'

import json
def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))
# print_json(w3.eth.get_transaction_receipt(tx_hash))

## Get tx info by tx_hash.
def tx_info():
    tx = w3.eth.get_transaction(tx_hash)
    # print_json(tx)
    print('to:', tx['to'])
    print('value:', tx['value'])
    print('gas:', tx['gas'])
    print('gasPrice:', tx['gasPrice'])
    print('nonce:', tx['nonce'])
# tx_info()

# Send from a1 to a2
def send_tx():
    tx = {
        'from': a1, 'to': a2,
        'value': w3.toWei("0.000001", "ether")
    }

    tx_hash = w3.eth.sendTransaction(tx)
    print(to_hex(tx_hash))
# send_tx()
# tx_hash = '0x37a947949e470ab638609d171ae90090594f8eac0a412d9eb43c6cb990b2c6f0'
# print_json(w3.eth.get_transaction_receipt(tx_hash))
# balances()
