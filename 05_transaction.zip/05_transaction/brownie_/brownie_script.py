## pip install eth-brownie
from brownie import *

def list_accounts():
    for a in accounts:
        print(a, a.balance())

def transfer():
    print(accounts[0].transfer(accounts[1], "10 ether"))
    print(accounts[1].balance())
    print(accounts[1].balance())

# Brownie script needs a main() as the starting point.
def main():
    list_accounts()
    # transfer()

## brownie run brownie_script.py
