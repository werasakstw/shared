import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* When the JVM is started, the "main" thread is created.
When the first class of an app is loaded, the "main" thread
  executes its main().
 
Thread.currentThread() returns the thread that executes this statement. */
class MainThread {
	public static void test() {
		Thread t = Thread.currentThread();
		System.out.println(t.getName());		// main
	}
}

/* There are many ways to create thread:

1. Subclass Thread  */
class MyThread extends Thread {
	MyThread(String n) { super(n); }
	public void run() {
		for (int i =0; i < 100; i++)
			System.out.print(Thread.currentThread().getName());
	}
}
class SubClass {
	public static void test() {
		Thread a = new MyThread("A");
		Thread b = new MyThread("B");
		a.start();
		b.start();
		// b.run();
		System.out.println("main stops");
	}
}

/* 2. Implement Runnable
Subclassing has more overhead than implementing interface. */
class MyRunnable implements Runnable {
	public void run() {
		for(int i = 0; i < 100; i++)
			System.out.print(Thread.currentThread().getName());
	}
}
class ImplRunnable {
	public static void test() {
		new Thread(new MyRunnable(), "A").start();
	}
}

/* 3. Using Anonymous Class
Mostly we use a thread only once, the class object should be garbage collected. */
class Anonymous {
	public static void test() {
		new Thread(new Runnable() {
			public void run() {
				for(int i = 0; i < 100; i++)
					System.out.print(Thread.currentThread().getName());
			}
		}, "A").start();
	}
}

/* 4. Using Lambda */
class Lambda {
	public static void test() {
		new Thread(() -> {
				for(int i = 0; i < 100; i++)
					System.out.print(Thread.currentThread().getName());
		}, "A").start();
	}
}

/* 5. Thread Pool */
class ThreadPool {
	public static void test() {
		ExecutorService es = Executors.newFixedThreadPool(10);
		es.execute(() -> {
			for(int i = 0; i < 100; i++)
				System.out.print(Thread.currentThread().getName()+", ");
		});
		es.shutdown();
	}
}

class Threads {
	public static void main(String args[]) {
		MainThread.test();
		// SubClass.test();
		// ImplRunnable.test();
		// Anonymous.test();
		// Lambda.test();
		// ThreadPool.test();
	}
}