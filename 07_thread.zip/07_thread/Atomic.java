import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/* Java 8 provides a set of atomic for thread safe counters. */
class AtomicTest {
	public static void test() {
		AtomicLong al = new AtomicLong();
		for (int i = 0; i < 10000; i++)
			new Thread(() -> { al.incrementAndGet(); }).start();
		try { Thread.sleep(1000); } catch(Exception ex) { }
		System.out.println(al.longValue());
	}
}
/* AtomicLong suffers performance because the optimistic increment
	requires locking the instance.
Java 8 provides LongAdder and LongAccumulator which are more efficient
if the value of the sum is not needed until after all the threads has been done. */
class AdderTest {
	public static void test() {
		final LongAdder a = new LongAdder();
		for (int i = 0; i < 1000; i++)
			new Thread(() -> { a.increment(); }).start();
		try { Thread.sleep(1000); } catch(Exception ex) { }
		System.out.println(a.longValue());
	}
}
/* There are also:
   		AtomicInteger, AtomicIntegerArray, AtomicIntegerFieldUpdater,
   		AtomicLongArray, AtomicLongFieldUpdater, AtomicReference,
   		AtomicReferenceArray, and AtomicReferenceFieldUpdater.
 These classes supports:
 		incrementAndGet()  getAndIncrement()
 		decrementAndGet()  getAndDecrement()
 		updateAndGet()
 		compareAndSet()
*/

//--------------------------------------------------------------

/* Java 8: Thread-safe Collections
If we modify a map while iterating,
	HashMap throws ConcurrentModificationException.
	ConcurrentHashMap takes care of the actions. */
class HashMapTest {
	public static void test() {
		Map<Integer, Integer> m = new HashMap<>();
		// Map<Integer,Integer> m = new ConcurrentHashMap<>();
		for (int i = 0; i < 10; i++)
			m.put(i, i);
		System.out.println(m);

		Iterator<Integer> it = m.keySet().iterator();
		while(it.hasNext()){
			Integer key = it.next();
			if (key == 3)
				m.put(33, 33);    // try: m.remove(3);
		}
		System.out.println(m);
	}
}

class Atomic {
	public static void main(String[] args) {
		AtomicTest.test();
		// AdderTest.test();
		// HashMapTest.test();
	}
}