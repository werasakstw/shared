/* Thread States:
	 public final class java.lang.Thread$State extends java.lang.Enum<java.lang.Thread$State> {
		  public static final java.lang.Thread$State NEW;
		  public static final java.lang.Thread$State RUNNABLE;
		  public static final java.lang.Thread$State BLOCKED;
		  public static final java.lang.Thread$State WAITING;
		  public static final java.lang.Thread$State TIMED_WAITING;
		  public static final java.lang.Thread$State TERMINATED;
		  public static java.lang.Thread$State[] values();
		  public static java.lang.Thread$State valueOf(java.lang.String);
		  static {};
	}
*/
class ThreadState {
	public static void test() {
		Thread t = new Thread();		// NEW
		System.out.println(t.getState());
		t.start();						// RUNNABLE
		Thread.State s;
		do {
			s = t.getState();
			System.out.println(s);
		} while (s != Thread.State.TERMINATED);
	}
}

/*	sleep() is static. Therefore the caller thread sleeps. */
class Sleep {
	public static void test() {
		class MyThread extends Thread {
			private long t;
			MyThread(String n, long t) {
				super(n);
				this.t = t;
			}
			public void run() {
				for (int i = 0; i < 100; i++) {
					System.out.print(getName());
					try {
						sleep(t);
					} catch (InterruptedException e) {
					}
				}
			}
		}
		new MyThread("A", 1).start();
		new MyThread("B", 2).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
		System.out.println("\nmain() stops");
	}
}

/* suspend() and resume() are deprecated since jdk 1.2. */
@SuppressWarnings({"deprecation", "removal"})
class Suspend {
	public static void test() {
		class MyThread extends Thread {
			MyThread(String s) { super(s); }
			public void run() {
				for (int i = 0; i < 50; i++){
					System.out.print(getName());
					try { sleep(1); } catch (InterruptedException e) { }
				}
			}
		}
		MyThread a = new MyThread("A");
		MyThread b = new MyThread("B");
		a.start(); b.start();
		try {
			Thread.sleep(10);
			a.suspend();
			System.out.println("\n A is suspended");
			Thread.sleep(10);
			a.resume();
			System.out.println("\n A is resumed");
		} catch (Exception e) {
			System.out.println("\n" + e);
		 }
	}
}

/* stop() makes the callee thread throws ThreadDeath error.
   stop() is deprecated since JDK 1.2.  */
@SuppressWarnings({"deprecation", "removal"})
class Stop {
	public static void test() {
		class MyThread extends Thread {
			public void run() {
				try {
					while(true) {
						sleep(1000);
						System.out.println("running");
					}
				} catch(Exception e) {
					System.out.println("\n" + e);
				}
				System.out.println("End");
			}
		}
		MyThread a = new MyThread();
		a.start();
		try { Thread.sleep(3000); } catch(InterruptedException e) { }
		a.stop();
	}
}

/* Interrupting a running thread just marks the thread interrupted
     and its isInterrupted() returns true. */
class Interrupt {
	public static void test() {
		Thread t = Thread.currentThread();
		System.out.println(t.isInterrupted()); // false
		t.interrupt();
		System.out.println(t.isInterrupted()); // true
	}
}

class SafeStop {
	public static void test() {
		class MyThread extends Thread {
			public void run() {
				while(true) {
					System.out.println("running");
					// doing something

					// at the end of the loop
					if (isInterrupted())
						break;
				}
				System.out.println("Performs post activity, and stop");
			}
		}
		MyThread t = new MyThread();
		t.start();
		try { Thread.sleep(1); } catch(InterruptedException e) { }
		t.interrupt();
	}
}

class Join {
	public static void test() {
		class MyThread extends Thread {
			MyThread(String s) { super(s); }
			public void run() {
				for (int i =0; i < 5; i++){
					System.out.print(getName());
					try { sleep(1000); } catch (InterruptedException e) { }
				}
			}
		}
		MyThread a = new MyThread("A");
		MyThread b = new MyThread("B");
		a.start(); b.start();
		try {
			a.join();
			b.join();
		} catch (InterruptedException e) { }
		System.out.println("Main stops");
	}
}

class DaemonThread {
	public static void test() {
		class MyThread extends Thread {
			public void run() {
				while(true) {
					try { Thread.sleep(1000); }catch(Exception e) { }
					System.out.println("Running");
				}
			}
		}
		MyThread a = new MyThread();
		a.setDaemon(true);
		a.start();
		try { Thread.sleep(3000); } catch(Exception e) { }
		System.out.println("Main stops");
	}
}

class State {
	public static void main(String args[]) {
		ThreadState.test();
		// Sleep.test();
		// Suspend.test();
		// Stop.test();
		// Interrupt.test();
		// SafeStop.test();
		// Join.test();
		// DaemonThread.test();
	}
}