import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import java.util.concurrent.ForkJoinPool;

class Core {
	public static void test() {
		System.out.println("Number of core: "
					+ Runtime.getRuntime().availableProcessors());

		ForkJoinPool p = ForkJoinPool.commonPool();
		System.out.println("Number of threads: "  + p.getParallelism());
	}
}


/*  Normal stream executes all input values sequentially in a single thread.
Parallel stream assigns an input value to a thread to be executed in a core. */
class ParallelStream {
	static void run(Stream<?> st) {
		long start = System.nanoTime();
		st.forEach(x -> {
            try {
			    TimeUnit.SECONDS.sleep(1);
		    } catch (InterruptedException ie) { }
        });
		long stop = System.nanoTime();
		System.out.printf(" %1.2g seconds.%n", (stop - start) / 1000000000.0);
	}
	public static void test() {
/* Sequential stream */
		run(Stream.of(1, 2, 3, 4));							// 4.0
/* Parallel stream */ 
		run(Stream.of(1, 2, 3, 4, 5).parallel());			// 1.0
	}
}

class ParallelSort {
	public static void test() {
/* Sort on parallel streams use the new Java 8 method Arrays.parallelSort()
to executed in parallel. But sort comparator is executed on the main thread. */
		Stream.of(3, 1, 4, 2)
			.parallel() // To enable parallel sort.
			.sorted((a, b) -> {
				// System.out.format("sort: %d <> %d [%s]\n", a, b, Thread.currentThread().getName());
				return a.compareTo(b);
			})
			.forEachOrdered(x ->   // Try: forEach
				System.out.printf("forEach: %d [%s]\n", x, Thread.currentThread().getName())
			);
	}
}

class Parallel {
    public static void main(String[] args) {
        Core.test();
        // ParallelStream.test();
        // ParallelSort.test();
    }
}