from eth_utils import *
from web3 import Web3
URL = "http://127.0.0.1:8545"
w3 = Web3(Web3.HTTPProvider(URL))

## Start Ganache
me = w3.eth.accounts[0]
john = w3.eth.accounts[1]
jack = w3.eth.accounts[2]
def eth_balances():
    print('me:', w3.eth.getBalance(me))
    print('john:', w3.eth.getBalance(john))
    print('jack:', w3.eth.getBalance(jack))
# eth_balances()

## Connect Remix to Ganache.
## Compile Erc20_Z.sol.
## Copy ERc20_Z abi to ERc20_Z.abi.
## Deploy ERc20_Z from 'me' at address:
con_addr = '0xE8981ACf6FC7E297F3991F8A2f7F543727729600'

## Read abi file.
def read_file(name):
    with open(name, 'r') as f:
        return f.read()
abi = read_file('contracts\Erc20_Z.abi')

## Get the contract from Ganache.
con = w3.eth.contract(address=con_addr, abi=abi)
# for f in con.all_functions():
#     print(f.fn_name)

def info():
    print(con.functions.name().call())
    # print(con.functions.symbol().call())
    # print(con.functions.totalSupply().call())
info()

## 'me' is the owner.
def m20_balances():
    print(con.functions.balanceOf(me).call())
    print(con.functions.balanceOf(john).call())
    print(con.functions.balanceOf(jack).call())
# m20_balances()

## Mint:
# print(to_hex(con.functions.mint(me, 1_000_000).transact({'from': me})))
# m20_balances()

## Transfer from 'me' to 'john'.
# print(to_hex(con.functions.transfer(john, 100).transact({'from': me})))
# m20_balances()

## Transfer from 'john' to 'jack'.
# print(to_hex(con.functions.transfer(jack, 10).transact({'from': john})))
# m20_balances()
