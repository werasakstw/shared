/* 'Self Reference' is the mechanism to refer to itself without
  knowing the name. 

'this' reference is a built-in 'self reference'.
Java allows accessing object state without qualifying name.
But 'this' can be used to distinguish between object member 
  and local name.  */
class A {
	int x;
	A(int x) { this.x = x; }
	void setX(int y) { 
        x = y;
        // this.x = y;
    }
}
// It 

/* 'this' may be passed as parameter.
'CallBack' is the situation that an object send its reference to 
  other object so that the reference can be used for calling back
  to the sender object. */
class B {
	void f(C c) { c.h(this); }
	void g() { System.out.println("B.g"); }
}
class C {
	void h(B b) { System.out.println("C.h"); b.g(); }
}
class CallBack {
	public static void test() {
		B b = new B();
		C c = new C();
		b.f(c);
	}
}

/* 'this' constructor allows a constructor to call other constructorw
  in the same class.
It is allowed in constructor only, not in methods.
It must be the first statement in a constructor and once only. */
class D {
 	D() { this(0); }
 	D(int x) {  }   // Circular calls can be detected by compiler.
}

/* Constructors should be overloaded to provide more than one
  ways to 'new' an instance, but all must be consistent
  that means the result should be the same.
To make thing simple, we choose one as a 'designated constructor'
  to performs all the initialization and all other constructors
  must call to the designated constructor. */
class E {
	int x;
	E() {   /* this() must be first statement in constructor. */
        // System.out.print("Hello");
		this(0);
		// this(0);         /* allow once only */
	}
	E(int x) { this.x = x; }
	E(K k) { this(k.x); }

/* this() cannot be called in methods. */
	// void f() { this(0); }
}
class This {
    public static void main(String args[]) {
        CallBack.test();
    }
}