package com.mypack;

class B {
	public void f() {
		System.out.println("com.mypack.B.f()");
	}
	void g() {
		System.out.println("com.mypack.B.g()");
	}
}