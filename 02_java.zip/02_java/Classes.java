/* A class is defined with class definition:
		class <name> { <members> }
<members> may be data, method, or class.  */
class A {
	int x = 1;				// data member
	void f() {				// method member
		System.out.println("A.f");
	}
	class B { 				// class member
		void f() {
			System.out.println("B.f");
		}
	}
}
class Instance {
	public static void test() {
/* An instance/object is created with:   
				new <class>(<argumemt>)
	Reference of the created instance is returned.  */
		A a = new A();

/* To access instance members with . (projection operator)
     via the instance reference.  */
		System.out.println(a.x);			// 1
		a.f();								// A.f

/* To create an instance of a member class, its container class
    instance must be created and used for 'new'.
				<instance>.new <class>(<argumemt)		  */
		A.B b = a.new B();
		b.f();							   // B.f
	}
}

/* Java allows 'method overloading' which is a class may have
  more than one methods with the same name but different parameters. */
class MethodOverLoad {
	public static void test() {
		class A {
			void f() { }
			void f(int x) { }
			// int  f(int x) { }   // Return type is not concerned.
			void f(char c, double d) { }
			void f(double d, char c) { }
			void f(Object o) { }
			void f(String o) { }
		}

		A a = new A();
		a.f();
		a.f(1);
		a.f('a', 1.0);
		a.f(1.0, 'a');
	}
}

/* Modifiers define property of members which may be
	1. Visibility:  */
class B {
	private int w = 1;		// private
	int x = 2;				// default (package public)
	protected int y = 3;	// protected (for subclasses)
	public int z = 4;
}
class Visibility {
	public static void test() {
 		B b = new B();
 		// System.out.print(b.w);		// compile time error
 		System.out.println(b.x + "," + b.y + "," + b.z);
 	}									// 2,3,4
} // More detail visibility in package and subclass.

/*  2. Mutability.  */
class C {
/* A 'final' simple type variable is immutable.	*/
	final int f = 1;
	static void f_test() {
		// f = 2;			// compile-time error
	}

	static class X {
		int x;
		void setX(int _x) { x = _x; }
 /* A name with _ prefixed is just a convention that denotes 
   the name is local, no special meaning.
   
A 'final' reference is immutable, but not its value. */
		public static void x_test() {
			final X x = new X();
			x.setX(1);
			// x = new X();		// Modify 'x' is not allowed.
		}
	}

	// A 'final' method cannot be overrided.
	class Y {
		final void f() {}
	}
	class Z extends Y {
		// void f() {}			// compile-time error
	}

	// A 'final' class cannot be extended.
	final class D {}
	// class E extends D {}		// compile-time error
}

class Classes {
	public static void main(String[] args) {
		Instance.test();
		// MethodOverLoad.test();
		// Visibility.test();
	}
}
