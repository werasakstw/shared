## Start Ganache or Anvil.
from myutil import *
from eth_utils import *

a0 = to_checksum_address(w3.eth.accounts[0])
# print(a0)

def balance():
    print('a0:', w3.eth.getBalance(a0))
# balance()

#-----------------------------------------------
## Read abi and bin.
abi = read_file('contracts/Storage.abi')
bin = read_file('contracts/Storage.bin')

## Create contract object.
con_obj = w3.eth.contract(abi=abi, bytecode=bin)

## List functions.
# for f in con_obj.all_functions():
#     print(f.fn_name)

#-----------------------------------------------

from eth_utils.curried import to_hex
## Deploy contract:
# print( to_hex(con_obj.constructor().transact({'from': a0})) )
tx_hash = '0xd96834313763bf36de1f7aa48aaba13aa5abff3dde0c2c4b299a1199b25af100'

## Get Contract Address
# print( w3.eth.get_transaction_receipt(tx_hash).contractAddress )
con_addr = '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512'

## Get Deployed Contract:
con = w3.eth.contract(address=con_addr, abi=abi)

#-----------------------------------------------
## Call retrieve(): call() does not create a tx.
# print(con.functions.retrieve().call())

## Alternatively A:
def alt_retrieveA():
    ''' 'data' is the 'function selector' that is the
    first 4 bytes of the hash of the function.  '''
    retrieve_hash = to_hex(w3.sha3(text='retrieve()'))[0:10]
    tx = { 'from': a0, 'to': con_addr,
            'data': retrieve_hash }
    # print(to_hex(w3.eth.sendTransaction(tx)))
    print(to_hex(w3.eth.call(tx)))
# alt_retrieveA()

#-----------------------------------------------
## Call store(): To modify contract state.
# print(to_hex(con.functions.store(1).transact({'from': a0})))
tx_hash = '0x3c1ea475ca6b098159e2b8627ca03fb93042eb9a72a5531267d1285720968267'

def check_result(tx_hash):
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    if tx_receipt != None:
        print(con.functions.retrieve().call())
# check_result(tx_hash)

## Alternatively A:
def alt_storeA():
    tx = con.functions.store(2).buildTransaction({
        'from': a0,
        'gas': "0x21000", 'gasPrice': "0x40000000" })
    tx_hash = to_hex(w3.eth.sendTransaction(tx))
    check_result(tx_hash)
# alt_storeA()

## Alternatively B:
def alt_storeB():
    _, data = to_data('store(uint256)', '3')
    tx = { 'from': a0, 'to': con_addr,
           'data': data,
           'gas': "0x21000", 'gasPrice': "0x40000000" }
    tx_hash = to_hex(w3.eth.sendTransaction(tx))
    check_result(tx_hash)
# alt_storeB()
