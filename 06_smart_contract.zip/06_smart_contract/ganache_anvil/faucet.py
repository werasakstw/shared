
from myutil import *
from eth_utils.curried import to_hex
from eth_utils import *

a0 = to_checksum_address(w3.eth.accounts[0]) # owner
a1 = to_checksum_address(w3.eth.accounts[1]) # deposit, withdraw

## Create contract object.
abi = read_file('contracts/Faucet.abi')
bin = read_file('contracts/Faucet.bin')
con_obj = w3.eth.contract(abi=abi, bytecode=bin)

## Deploy contract.
# tx_hash = to_hex(con_obj.constructor().transact({'from': a0}))
# print(tx_hash)
tx_hash = '0x99461e395a0cd8df75db6712a2842170a86436d7efff6d449853962214ee134f'

## Get deployed contract.
# con_addr = w3.eth.get_transaction_receipt(tx_hash).contractAddress
# print(con_addr)
# con = w3.eth.contract(address=con_addr, abi=abi)

def balances():
    print(w3.eth.get_balance(a0))
    print(w3.eth.get_balance(a1))
    print(w3.eth.get_balance(con_addr))
# balances()

''' Deposit. There is no deposit() in the Faucet contract.
If a tx send value to a contract address without data
 the value is added to the contract balance. '''
def deposit(depositor_addr, value):
    tx = { 'from': depositor_addr, 'to': con_addr, 'value': value }
    print(to_hex(w3.eth.sendTransaction(tx)))
# deposit(a0, 100); balances()
# deposit(a1, 200); balances()

def withdraw(withdrawer_addr, value):
    tx = con.functions.withdraw(value).buildTransaction({
        'from': withdrawer_addr,
        'gas': "0x21000", 'gasPrice': "0x40000000"  })
    print(to_hex(w3.eth.sendTransaction(tx)))
# withdraw(a0, 100); balances()
# withdraw(a1, 10); balances()
