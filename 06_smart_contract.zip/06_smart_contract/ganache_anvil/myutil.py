from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

def read_file(name):
    with open(name, 'r') as f:
        return f.read()

def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)

import json
def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))

from eth_utils.curried import to_hex
def to_data(f, a):
    h = to_hex(w3.sha3(text=f))
    # print(h)
    func = h[2:10]
    # print(func)

    ## padded to 36 bytes (72 chars)
    z = 72 - (len(func) + len(a))
    data = func + '0'*z + a
    return len(data), data
# print(to_data('store(uint256)', '3'))
