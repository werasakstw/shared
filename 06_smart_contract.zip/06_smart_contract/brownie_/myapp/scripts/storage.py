from brownie import *

def list_accounts():
    for a in accounts:
        print(a, a.balance())

def main():
    s = Storage.deploy({'from': accounts[0]})
    print(s.retrieve())
    s.store(1)
    print(s.retrieve())

## brownie run storage.py
## brownie run storage.py list_accounts
