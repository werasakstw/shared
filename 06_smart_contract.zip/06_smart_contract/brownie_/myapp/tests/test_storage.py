## The test file and test function start with 'test'.
def test_1(Storage, accounts):
    s = Storage.deploy({'from': accounts[0]})
    assert s.retrieve() == 0
    s.store(1)
    assert s.retrieve() == 1

## brownie test
