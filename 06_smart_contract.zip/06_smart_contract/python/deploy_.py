from myutil import *
from eth_utils.curried import to_hex

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
# print(w3.eth.get_balance(me_addr))

### Using contract constructor, using both abi and bin.
def deploy(fn):
    abi = read_file('contracts/' + fn + '.abi')
    bin = read_file('contracts/' + fn + '.bin')

    # Create contract object (not deployed).
    con = w3.eth.contract(abi=abi, bytecode=bin)
    nonce = w3.eth.getTransactionCount(me_addr)
    tx = con.constructor().buildTransaction({
        'nonce': nonce, 'chainId': "0x4",
        'gas': "0x21000", 'gasPrice': "0x40000000",  # currGas
    })

    # Sign and sender tx.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# deploy('Storage')
tx_hash = '0x4eef9b7393a5cfa1f6cbc5b52b195eaf76971344351cb960a7b61060db5bded6'

## Transaction Receipt
tx_rc = w3.eth.get_transaction_receipt(tx_hash)
# print_json(tx_rc)

## Contract Address
# print(tx_rc.contractAddress)
st_addr = '0x87F8333E0B6dEB2eA43d8506f3A682Cd5e50a9CC'

# Test deployed contract:
def test_contract(fn, addr):
    abi = read_file('contracts/' + fn + '.abi')
    c = w3.eth.contract(address=addr, abi=abi)
    for f in c.all_functions():
        print(f.fn_name)
# test_contract('Storage', st_addr)
