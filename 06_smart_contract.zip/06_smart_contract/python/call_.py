from myutil import *
''' The smart contract address can be found by checking
 'to' of the tx that deploy the contract, using Etherscan. '''

## Getting Storage smart contract using address and abi.
st_addr = '0x87F8333E0B6dEB2eA43d8506f3A682Cd5e50a9CC'
# '0xC7d441B41C329bCC8e09616488D332DCc142b650'
st_abi = read_file('contracts/Storage.abi')
st_con = w3.eth.contract(address=st_addr, abi=st_abi)

## Calling getter(read-only) method needs no gas.
# print(st_con.functions.retrieve().call())

## Setter: needs a signed tx and gas.
me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
def st_setter(value):
    nonce = w3.eth.getTransactionCount(me_addr)
    tx = st_con.functions.store(value).buildTransaction({
        'nonce': nonce, 'chainId': 4,
        'gas': "0x21000", 'gasPrice': "0x40000000"
    })
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# st_setter(1)
tx_hash = '0x46f6d3fd9b94ef0cc5acedc3768ca164a3cf1176243bcc629f2c764f09a1479b'
# print_json(w3.eth.get_transaction_receipt(tx_hash))

# print(st_con.functions.retrieve().call())
