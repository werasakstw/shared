# Microsoft Visual C++ 14.0 or greater is requuired.
#   Install vs_BuildTools  -> Modify -> Install C++

# pip install --upgrade setuptools
# pip install web3
# https://web3py.readthedocs.io/en/stable/
# https://blog.logrocket.com/web3-py-tutorial-guide-ethereum-blockchain-development-with-python/

from web3 import Web3
url = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(url))

# print(w3.clientVersion)
# print(w3.eth.mining)
# print(w3.eth.gasPrice)
# print(w3.net.peer_count)
# print(w3.eth.accounts)
