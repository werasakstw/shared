## pip install requests
import requests

URL = 'http://127.0.0.1:8545'
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def jsonrpc(method):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": [], "id": 1}' % method
   # print(DATA)
   return requests.post(URL, data=DATA, headers=HEADERS).text

res = jsonrpc('web3_clientVersion')
print(res)

res = jsonrpc('eth_accounts')
print(res)             # str

import json
js = json.loads(res)   # str -> json
print(js['result'])
print(js['result'][0])
