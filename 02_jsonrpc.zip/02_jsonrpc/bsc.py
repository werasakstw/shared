# Register at:
# 	https://accounts.binance.com/en/register

# pip install python-binance

API_KEY = 'MFiwBMqiOoNjJvYeIAcPxJKW4O393Wbc7rXcufRECohY3JuR410MSTFA2aYiozmz'
SECRET_KEY = 'RGgn4cHmSe61X3xCinmh5mWkglbwHFA97w5XaK99z6x4cxHRY1j2fKcULNHsE2E0'

from binance.client import Client
def get_client():
    client = Client(API_KEY, SECRET_KEY)
    client.API_URL = 'https://testnet.binance.vision/api'
    return client

c = get_client()

## Latest Price
# print(c.get_symbol_ticker(symbol='BNBUSDT'))
# print(c.get_symbol_ticker(symbol='BTCUSDT'))
# print(c.get_symbol_ticker(symbol='ETHUSDT'))

## Client Account:
# print(c.get_account())

## All balances
# print(c.get_account()['balances'])

## BNB balance
# print(c.get_account()['balances'][0])
# print(c.get_asset_balance(asset='BNB'))
