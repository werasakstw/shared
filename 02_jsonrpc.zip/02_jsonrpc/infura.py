# Register at:     https://infura.io/
# https://mainnet.infura.io/v3/1c33caf701824d43882200b69d5e0849
# https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849

from web3 import Web3
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

# Infura needs a middleware to modify message between client and node.
from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

print(w3.clientVersion)
# print(w3.eth.chain_id)      # 4  Rinkeby chain id.
# print(w3.net.peer_count)    # w3.net.peerCount

# Check if the infura node is accessible?
# print(w3.isConnected())     # w3.net.listening

# Get the current price per gas in wei.
# print(w3.eth.gasPrice)

# Infura is not a wallet.
# print(w3.eth.accounts)      # []

# Infura does not perform mining.
# print(w3.eth.mining)        # False
# Get the node Hash rate, zero if not a minier node.
# print(w3.eth.hashrate)

# Infura node has no Blockchain and does not perform syncing.
# print(w3.eth.syncing)       # False

# Get most recent block number (of Rinkeby chain).
# print(w3.eth.blockNumber)

# Get block
# lb = w3.eth.get_block('latest')
# print(w3.toHex(lb.hash))
