'''  Bitcoin Core GUI:
cd C:\Program Files\Bitcoin
bitcoin-qt

# Setting -> Option -> Open Configuration File

server = 1
rpcbind = 127.0.0.1:8332
rpcuser = rambo
rpcpassword = hello123

'''
#----------------------------------------------

# pip install python-bitcoinrpc

from bitcoinrpc.authproxy import AuthServiceProxy, JSONRPCException
user = "rambo"
pwd = "hello123"
url = "http://%s:%s@127.0.0.1:8332" % (user, pwd)
api = AuthServiceProxy(url)

print(api.getblockchaininfo())
# print(api.getblockcount())
