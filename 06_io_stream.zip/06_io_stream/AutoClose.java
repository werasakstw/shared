import java.io.*;

/* Java 7, an 'auto closeable' class implements AutoCloseable interface,
  and has close() method. */
class A implements AutoCloseable {
		public void hello() {				// resource-specific method
			System.out.println("Hello.");
		}
		// @Override
		public void close() throws Exception {
			System.out.println("Goodbye!");
		}
}
/* Java 7 introduces 'resource block' in the try-catch.
		try (<resource block>) { } catch () {<catch block>}
All objects created in resource block must be AutoCloseable.
The close() of objects will be executed automatically when the try block exits
No matter an exception is thrown or not. */
class ResourceBlock {
	public static void test() {
		try ( A a = new A(); ) {
			a.hello();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}							// Hello.
	}								// Goodbye!
}
//-----------------------------------------------

/* PreJava 7, closing a stream properly is very awkward. */
class PreJava7 {
	public static void test() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("index.txt"));
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

/* Using Java7 Resources Block */
class Java7 {
	public static void test() {
		try (
			BufferedReader br = new BufferedReader(new FileReader("index.txt"));
		) {
			String s;
			while ((s = br.readLine()) != null)
				System.out.println(s);
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}

class AutoClose {
	public static void main(String args[]) {
		ResourceBlock.test();
		// PreJava7.test();
		// Java7.test();
	}
}
