import java.io.IOException;
/* Stream Type is the type of values that pass through the stream.
	1. Byte Streams:
				InputStream
				OutputStream
	2. Char Streams:
				Reader
				Writer
	3. Object Streams:
				ObjectInputStream
				ObjectOutputStream

There are predefined streams defined in 'System' class:
			public static final InputStream in;
			public static final PrintStream out;
			public static final PrintStream err;
'in' is connected to stdin, default is keyboard.
'out' and 'err' are connected to stdout by default.  */
class Predefined {
	public static void test() {
		System.out.println("Hello");
		System.err.println("Hi");
	}
}

/* java.io.InputStream
	public abstract int read() throws java.io.IOException;
	public int read(byte[]) throws java.io.IOException;
	public int read(byte[], int, int) throws java.io.IOException;

  java.io.OutputStream
	public abstract void write(int) throws java.io.IOException;
	public void write(byte[]) throws java.io.IOException;
	public void write(byte[], int, int) throws java.io.IOException;

read() : read one byte to the lower byte of the return value.
write(int): write the lower byte of the int parameter.

We read/write one byte at time for the stream that we cannot see the EOF
ex. keyboard and socket.

EOF:	Ctrl+Z (Window)
        Ctrl+D (Unix)  */
class Read {
	public static void test() {
		int c = 0;
		try {
			while ((c = System.in.read()) != -1)
				System.out.write(c);
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}
/* Try: java Streams < Streams.java
		 java Streams <Streams.java >t.txt */

/* Read/Write an array of bytes.
Mostly we read/write in size of sectors(multiples of K bytes). */
class Reads {
	public static void test() {
		int c;		// number of read bytes
		byte b[] = new byte[1024];
		try {
			while ((c = System.in.read(b)) != -1)
				System.out.write(b, 0, c);
		} catch (Exception e) {
			System.err.println(e);
		}
	}
} // Try: java Streams < Streams.java

/* Read a whole file at once.
available() must be used with the stream that has EOF. */
class Available {
	public static void test() {
		try {
			int n = System.in.available();
			byte[] b = new byte[n];
			System.in.read(b);
			System.out.write(b);
		} catch(IOException e) {
			System.err.println(e);
		}
	}
} // Try: java Streams < Streams.java

class Streams {
	public static void main(String args[]) {
		Predefined.test();
		// Read.test();
		// Reads.test();
		// Available.test();
	}
}
