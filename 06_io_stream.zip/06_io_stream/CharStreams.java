import java.io.*;

/*	Character Streams:
 java.io.Reader
	public int read() throws IOException;
	public int read(char[ ]) throws IOException;
	public abstract int read(char[ ], int, int) throws IOException;

java.io.Writer
	public void write(int)  throws IOException;
	public void write(char[ ]) throws IOException;
	public abstract void write(char[ ], int, int)  throws IOException;

public class java.io.InputStreamReader extends java.io.Reader
	converts input byte stream into input char stream

public class java.io.OutputStreamWriter extends java.io.Writer
	OutputStreamWriter: convert output char stream into  output byte stream
*/
class StreamRW {
	public static void test() throws IOException {
		int n;
		char [] b = new char [1024];
		InputStreamReader isr = new InputStreamReader(System.in);
		OutputStreamWriter osw = new OutputStreamWriter(System.out);
		while ((n = isr.read(b)) > 0)
			osw.write(b, 0, n);
		osw.close();
	}
} // Try: java CharStreams < CharStreams.java

/* Reader and Writer allow setting the encoding. */
class Encoding {
	public static void test() throws IOException {
		OutputStreamWriter isr = new OutputStreamWriter(System.out);
		System.out.println(isr.getEncoding());

		OutputStreamWriter osw =  new OutputStreamWriter(System.out, "MS874");
		// OutputStreamWriter osw = new OutputStreamWriter(System.out,  "Cp1252");
		System.out.println(osw.getEncoding());
		osw.write('\u0E01');
		osw.close();
	}
}
class CharStreams {
	public static void main(String args[]) throws IOException {
		// StreamRW.test();
		Encoding.test();
	}
}
