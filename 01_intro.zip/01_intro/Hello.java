class Hello {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
/* 
1. Set Env: systempropertiesadvanced.exe
		JAVA_HOME
		%JAVA_HOME%\bin

2. Command line:
cd C:\myjava\01_intro
javac Hello.java
java Hello

Since Java12:
java Hello.java

*/
