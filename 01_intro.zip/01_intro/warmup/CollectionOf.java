import java.util.*;
/* Java does not support collection literals e.g. list and set.
Java 9 introduces collection factory. */
class CollectionOf {
    public static void main(String[] args) {
        List<String> l = List.of("john", "jack", "joe");
        System.out.println(l);      // [john, jack, joe]

        Set<Integer> s = Set.of(3, 1, 2);
        System.out.println(s);      // [1, 2, 3]
    }
}