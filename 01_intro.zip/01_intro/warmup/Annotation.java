import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* 'Annotation' is a mechanism for attaching meta information
  to the codes without effect to the execution. */

@Retention(RetentionPolicy.RUNTIME)
@interface Version { 
	public int major(); 
	public int minor();
}

@Version(major = 1, minor = 1)
class C { }

class Annotation {
	public static void main(String args[]) {
		Version v = C.class.getAnnotation(Version.class);
		System.out.println("Version: " + v.major() + "." + v.minor());
	}
}

class SuperClass {
	public void f(int x) { }
}
class SubClass extends SuperClass {
	@Override
	public void f(int x) { }
}
