// Java 5 introduced	Variable Length Arguments.
class VarArg {
	static void f(int ...x) {
		for (int i : x)
			System.out.print(i + ", ");
		System.out.println();
	}
	public static void main(String args[]) {
		f();
		f(1);
		f(1,2);
		f(1,2,3);
	}
}
/*
VarArg type must be the last parameter.
	(int... a, int b)
No more than one VarArg parameter.
	(int... a, String... b)
No parameter with the same type before VarArg.
	(int a, int... b)
*/
