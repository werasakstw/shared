/* 'class path' is a list of paths (to directories or jar files)
 where the class loader looks for classes to be loaded.
*/
class Main {
	public static void main(String[] args) {
		(new beans.Hello()).hello();
	}
}
/*  java -verbose Main >t.txt
1. If no CLASSPATH, the default 'class path' is
		- %JAVA_HOME%\jre\lib\*.jar			JDK1.8
		- working dirctory.

From the working dirctory.
  beans.Hello is related from working dirctory.
javac Main.javac
java Main

2. Move \beans to c:\tmp
set CLASSPATH=c:\tmp
java Main		// ClassNotFoundException: beans.Hello

If the CLASSPATH is set, 
 the working dirctory is not in 'class path'.
set CLASSPATH=c:\tmp;.
*** So mostly . should be included in CLASSPATH.

3. Create jar file.
cd c:\tmp
jar -cf j.jar .
jar -tf j.jar
Move j.jar to working dirctory.
set CLASSPATH=			// reset CLASSPATH
java Main				// jar file is not 'class path' by default.
set CLASSPATH=j.jar;.

2. Include jar file in CLASSPATH.
set CLASSPATH=%PATH%;m.jar;.
java Main
-----------------------------------------

Application in jar.
1. Create manifest file m.txt.
2. Move \beans back to working director.
In the working dirctory.
jar -cfm m.jar m.txt .
java -jar m.jar
*/
