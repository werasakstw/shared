package beans;

public class Hello {
	public void hello() {
		System.out.println("Hello");
	}
}
