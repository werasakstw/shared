/* 'java.exe' starts the JVM, load the first class, that cantains
  main() and executes main() (without creating object of the class).
Therefore main() must be:
  - 'public' and'static'.
  - 'return type' is 'void' and cannot return anything, even a null.
  - Has 'String[] args' as parameter.
  - Can be overloaded, but only the valid one is executed, other 
      versions can be explicitly called.

A 'Java application' is a set of classes that at least has one class
    contains main() as the starting point.   */
class Main {
    public static void main(String[] args) {
        System.out.println("Hello");      // Hello
        Main.main();                      // main
        // return null;               // Try: Uncomment this line.
    }
    public static void main() {
        System.out.println("main");
    }
    /* Java code is case sensitive. */ 
    public static void Main(String[] args) {
      System.out.println("Main");
   }
}
