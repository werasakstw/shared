class I {
	public static void main(String args[]) {
        System.out.println("I am I.");
        new J().f();
    }
}

