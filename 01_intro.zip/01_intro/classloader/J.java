class J {
	void f() {
        System.out.println("I am J.");
        new K().f();
    }
}

