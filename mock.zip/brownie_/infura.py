from web3 import Web3
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

def main():
    print(w3.clientVersion)

if __name__ == '__main__' :
    main()
