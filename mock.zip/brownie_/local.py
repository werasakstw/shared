from web3 import Web3
url = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(url))

def main():
    print(w3.clientVersion)
    # for a in w3.eth.accounts:
    #     print(a, w3.eth.getBalance(a))

if __name__ == '__main__' :
    main()
