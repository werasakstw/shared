
import bitcoin as bc

# Wallets may handle a set of accounts.
# Saving accounts in storage is not a good idea.
# There are ways to repeatedly compute accounts from a password.

## Deterministic Wallet (D Wallet):
# Using password and index as seeds to generate account.
def deterministic(pwd):
    for i in range(5):
        seed = pwd + str(i)
        private_key = bc.sha256(seed)
        print(i, bc.privkey_to_address(private_key))

    # To recompute address of index 3.
    pk = bc.sha256(pwd + str(3))
    print(bc.privkey_to_address(pk))
# deterministic('rambo500')

## Mnemonic: is a stronger password, it compose of a list of words.

# pip install mnemonic
from mnemonic import Mnemonic

## Languages List:
# print(Mnemonic.list_languages())

## English Words List:
# print(Mnemonic('english').wordlist)

## Create entropy from an randomness:
# An entropy must be a 16, 20, 24, 28, or 32 hexadecimal digits string.
import random
def gen_entropy():
    r = ''
    for i in range(random.choice([16, 20, 24, 28, 32])):
        r += '{:x}'.format(random.randint(0, 15))
    return r.encode()   ## bytes array
# print(gen_entropy().decode())

## Create Mnemonic from entropy:
def gen_mnemonic(entropy):
    return Mnemonic('english').to_mnemonic(entropy)
# print(gen_mnemonic(gen_entropy()))

## Create Seed from mnemonic and password:
# A mnemonic is used for generate a seed the process can be protected
#  with a the mnemonic's password.
def to_seed(mnemonic, password):
    return Mnemonic.to_seed(mnemonic, passphrase=password)
def gen_seed():
    my_mnemonic = 'corn coyote snow hockey great rain system educate good arch escape shift'
    my_password = 'hello123'
    my_seed = to_seed(my_mnemonic, my_password)
    return my_seed.hex()
# print(gen_seed())
my_seed = 'c84b43ad6f251e024bf74f8892179770d2bec4692b90da0833720f007dfba4782f76db7b98bef53cfa74fd2412280d8f9739ddd5e137046e792449d3645b6814'

## Hierarchical Deterministic Wallets (HD Wallet)
# Addresses are organized as a tree.

# pip install bip32utils
from bip32utils import BIP32Key
from binascii import hexlify

## Child Key Derivation:
# A seed is used for creating a root key.
def bip32_test(seed):
    ## Create BIP32Key: from entropy
    root_key = BIP32Key.fromEntropy(seed.encode(), public=False)
    print(root_key.Address())
    # 1DzWkK5KezVrNP8o7Xwi4jGQ7eGGzGjw1r
    # print(hexlify(root_key.PrivateKey()).decode())
    # print(hexlify(root_key.PublicKey()).decode())

    ## Create index 'i' child key of of root key
    for i in range(3):
        print(i, root_key.CKDpriv(i).Address())
    print()

    ## Create index 'j' child key of of the first child key
    c0 = root_key.CKDpriv(0)
    for j in range(3):
        print(j, c0.CKDpriv(j).Address())
# bip32_test(my_seed)

def get_addr(seed, i, j):
    root_key = BIP32Key.fromEntropy(seed.encode(), public=False)
    return root_key.CKDpriv(i).CKDpriv(j).Address()
# print(get_addr(my_seed, 0, 1))
