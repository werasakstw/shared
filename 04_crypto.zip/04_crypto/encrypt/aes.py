# pip install pycryptodome

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
from eth_utils import encode_hex, decode_hex

def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)
def read_file(name):
    with open(name, 'r') as f:
        return f.read()

''' AES encoding:
The key is generated correspod to a message.
Keys are 16 bytes (hex str).
An encoded message contains initialized vector(iv)
 and ciphertext(ct), represented as json with base64 values.
'''
import json
def encode(msg):
    data = msg.encode()
    key = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data, AES.block_size))
    iv = b64encode(cipher.iv).decode('utf-8')
    ct = b64encode(ct_bytes).decode('utf-8')
    write_file('key', encode_hex(key))
    write_file('encoded', json.dumps({'iv':iv, 'ct':ct}))
# encode("Hello how do you do?")

from Crypto.Util.Padding import unpad
def decode():
    try:
        key = decode_hex(read_file('key'))
        enc = json.loads(read_file('encoded'))
        iv = b64decode(enc['iv'])
        ct = b64decode(enc['ct'])
        cipher = AES.new(key, AES.MODE_CBC, iv)
        msg = unpad(cipher.decrypt(ct), AES.block_size).decode()
        print(msg)
    except (ValueError, KeyError):
        print("Error")
# decode()
