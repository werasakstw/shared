# pip install pycryptodome

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
from eth_utils import encode_hex, decode_hex
import json
from myutil import *

def encode(msg):
    data = msg.encode()
    key = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data, AES.block_size))
    iv = b64encode(cipher.iv).decode('utf-8')
    ct = b64encode(ct_bytes).decode('utf-8')
    write_file('key', encode_hex(key))
    write_file('encoded', json.dumps({'iv':iv, 'ciphertext':ct}))
# encode("Hello how do you do?")

from Crypto.Util.Padding import unpad
def decode():
    try:
        key = decode_hex(read_file('key'))
        b64 = json.loads(read_file('encoded'))
        iv = b64decode(b64['iv'])
        ct = b64decode(b64['ciphertext'])
        cipher = AES.new(key, AES.MODE_CBC, iv)
        msg = unpad(cipher.decrypt(ct), AES.block_size).decode()
        print(msg)
    except (ValueError, KeyError):
        print("Error")
# decode()
