import random
from myutil import *
from eth_utils import encode_hex, decode_hex

# Exclude Symbols: 1, 0, I, o, O.
SYM = '23456789aAbBcCdDeEfFgGhHijJkKmMnNpPqQrRsStTuUvVwWxXyYzZ'
def gen_pwd():
   pwd = ''
   for _ in range(random.randint(4, 6)): # 4 to 6 characters.
      pwd += random.choice(SYM)
   return pwd
# print(gen_pwd())

def is_valid_pwd(pwd):
   if type(pwd) is str:
      if 4 <= len(pwd) <= 6:
         for c in pwd:
            if c not in SYM:
               return False
         return True
   return False

def pwd_test():
    for _ in range(10):
        pwd = gen_pwd()
        print(pwd, is_valid_pwd(pwd))
# pwd_test()

#------------------------------------------------------

def encode(text, pwd):
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   key = int.from_bytes(pwd.encode(), 'big')
   text_bytes = int.from_bytes(text.encode(), 'big')
   write_file('encoded', str(key ^ text_bytes))
private_key = '981e355811ee4b29aaac91d41ac37e1d6679b38a1631b95b07f1f31d9c7186a8'
pwd = 'hi234'
encode(private_key, pwd)

def decode(encoded_file, pwd):
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   enc = int(read_file(encoded_file))
   key = int.from_bytes(pwd.encode(), 'big')
   text_bytes = key ^ enc
   length = text_bytes.bit_length()
   text = text_bytes.to_bytes((length+ 7) // 8, 'big')
   return text.decode()
# print(decode('encoded', pwd))
