def encode(msg, key):
    slot = [''] * key
    for col in range(key):
        cur = col
        while cur < len(msg):
            slot[col] += msg[cur]
            cur += key
    return ''.join(slot)

def encode_test():
    msg = '1234567890'
    for key in range(1, 5):
        enc_msg = encode(msg, key)
        print(key, enc_msg)
# encode_test()
            # 1 1234567890
            # 2 1357924680
            # 3 1470258369
            # 4 1592603748

msg = 'Hello how are you?'
def key_test():
    for key in range(1, len(msg)+2):
        enc_msg = encode(msg, key)
        print(key, enc_msg)
# key_test()
# Keys are not good when greater than half of msg length,
# and do not work when equal or greater than the msg length.

import math
def decode(enc_msg, key):
    ncol = math.ceil(len(enc_msg) / key)
    nrow = key
    nboxes = (ncol * nrow) - len(enc_msg)
    dmsg = ['']*ncol
    col, row = 0, 0
    for i in enc_msg:
        dmsg[col] += i
        col += 1
        if (col == ncol) or (col == ncol-1 and row >= nrow-nboxes):
            col = 0
            row += 1
    return ''.join(dmsg)

def decode_test():
    enc_msg = encode(msg, 8)
    print(enc_msg)              # Hwue ?lalroe  hyoo
    print(decode(enc_msg, 8))   # Hello! how are you?
# decode_test()
