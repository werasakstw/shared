def xor_test():
    msg = 12345
    key = 741
    enc_msg = msg ^ key  # XOR
    print(enc_msg)          # 13020
    print(enc_msg ^ key)    # 12345
# xor_test()

# 'msg' must be a str.
msg = 'Hello how are you?'

# Create an int from a bytes array.
# print(int.from_bytes(msg.encode(), 'big'))
# 6306597225791273124442517294019003825485119

from secrets import token_bytes
# Generate random bytes string.
# Some bytes cannot be mapped to printable symbol,
#  so decode() is not applicable.
def token_bytes_test():
    for i in range(5):
        print(token_bytes(i))
# token_bytes_test()

# Generate a key from message.
def genkey(msg):
    length = len(msg.encode())
    return int.from_bytes(token_bytes(length), 'big')
key = genkey(msg)
# print(key)  # 7899269739059894676288955662058790306366057

def encode(msg, key):
    return key ^ int.from_bytes(msg.encode(), 'big')
enc_msg = encode(msg, key)
# print(enc_msg)  # 15688729724374416781269505552827327859701458

def decode(enc_msg, key):
    msg_bytes = key ^ enc_msg
    length = msg_bytes.bit_length()
    return msg_bytes.to_bytes((length+ 7) // 8, 'big').decode()
# print(decode(enc_msg, key))  # Hello how are you?
