def partition(msg):
    evens = []  # For characters at even positions.
    odds = []   # For characters at odd positions.
    for i, c in enumerate(msg):
        if i % 2 == 0:
            evens.append(c)
        else:
            odds.append(c)
    return evens, odds
# print(partition('Hello! how do you do?'))

# Swap adjacent characters.
def swap(msg):
    # For odd length msg adds an extra space.
    if len(msg) % 2 != 0:
        msg += ' '
    even_letters, odd_letters = partition(msg)
    letters = []
    for i in range(0, int(len(msg)/2)):
        letters.append(odd_letters[i])
        letters.append(even_letters[i])
    return ''.join(letters)

msg = 'Hello! how do you do?'
def swap_test():
    # encode
    print(swap(msg))        # eHll!oh wod  ooy uod ?
    # decode
    print(swap(swap(msg)))  # Hello! how do you do?
# swap_test()

#-----------------------------------------------------------

# An improve version.
from random import choice
fake_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'i', 'o', 'r', 's', 't', 'u', 'v']
def encode(msg):
    enc = []
    # Add a random fake letter at even positions.
    for c in msg:
        enc.append(c)
        enc.append(choice(fake_letters))
    return ''.join(enc)
enc_msg = encode(msg)
# print(enc_msg)    # Hoeelelgos!i uhforwb vdbov oycobus bdgof?b
# Encoded msg is double size of msg.

def decode(msg):
    # Only odd positions contain the msg.
    odds, _ = partition(msg)
    return ''.join(odds)
# print(decode(enc_msg))
