import string
_symbols = string.printable
_symbols_len = len(_symbols)
# print(_symbols_len, _symbols)

# 'msg' must be a printable string.
# 'key' is an integer.
def encode(msg, key):
    def _encode(c):
        ec = (_symbols.find(c) + key) % _symbols_len
        return _symbols[ec]
    enctxt = ''
    for c in msg:
        enctxt += _encode(c)
    return enctxt

key = 123
msg = 'Hello It`s nice to see you!'
enc_msg = encode(msg, key)
# print(enc_msg)

def decode(enc_msg, key):
    def _decode(c):
        dc = (_symbols.find(c) - key) % _symbols_len
        return _symbols[dc]
    msg = ''
    for c in enc_msg:
        msg += _decode(c)
    return msg
# print(decode(enc_msg, key))

# Suppose we have a cue that the message contains a word 'you'.
def brute_force():
    for k in range(_symbols_len):
        et = decode(enc_msg, k)
        if 'you' in et:
            print(k, et)
            break
# brute_force()
