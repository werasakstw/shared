import string, random

# Generate a mapping for encrypt and decrypt.
def gen_map():
    l = list(string.printable)
    random.shuffle(l)
    target = ''.join(l)
    return str.maketrans(string.printable, target), \
           str.maketrans(target, string.printable)
encrypt_map, decrypt_map = gen_map()
# print(encrypt_map)  # For encoder.
# print(decrypt_map)  # For decoder.
# Exposing any of the maps would be disastrousใ

msg = 'Hello! how are you?'
def map_test():
    # encode
    enc_msg = msg.translate(encrypt_map)
    print(enc_msg)  # V]==UW^kU2^y@]^wUI[

    # decode
    print(enc_msg.translate(decrypt_map))
# map_test()          # Hello! how are you?
