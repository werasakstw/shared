## Generate password:
# Exclude Symbols: 1, 0, I, o, O.
# Length from 4 to 6 characters.
SYM = '23456789aAbBcCdDeEfFgGhHijJkKmMnNpPqQrRsStTuUvVwWxXyYzZ'
import random
def gen_pwd():
    pwd = [random.choice(SYM) for _ in range(random.randint(4, 6))]
    return ''.join(pwd)
# print(gen_pwd())

def is_valid_pwd(pwd):
   if type(pwd) is str:
      if 4 <= len(pwd) <= 6:
         for c in pwd:
            if c not in SYM:
               return False
         return True
   return False

def pwd_test():
    for _ in range(10):
        pwd = gen_pwd()
        print(pwd, is_valid_pwd(pwd))
# pwd_test()

#------------------------------------------------------

# 'text' and 'pwd' are strings.
def encode(text, pwd):
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   key = int.from_bytes(pwd.encode(), 'big')
   text_int = int.from_bytes(text.encode(), 'big')
   return key ^ text_int      # int

private_key = '981e355811ee4b29aaac91d41ac37e1d6679b38a1631b95b07f1f31d9c7186a8'
pwd = 'hi234'
enc = encode(private_key, pwd)
# print(enc)

def decode(enc, pwd):
   if not is_valid_pwd(pwd):
      return 'Invalid password'
   key = int.from_bytes(pwd.encode(), 'big')
   text_int = key ^ enc     # int
   length = text_int.bit_length()
   text = text_int.to_bytes((length+ 7) // 8, 'big')
   return text.decode()

# print(decode(enc, pwd))
