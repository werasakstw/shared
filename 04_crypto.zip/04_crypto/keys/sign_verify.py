## To verify transaction integrity:
# It is possible that someone happen to know Jack public key.
# And Jack's transaction may be tampered during transfered.
# Jack must use his private key to sign the transaction resulting
#   a signature and save the signature with the transaction for verification.

import bitcoin as bc
pri_key = bc.sha256('Hello')
pub_key = bc.privkey_to_pubkey(pri_key)
addr = bc.pubkey_to_address(pub_key)

msg = 'Hello how do you do?'

## Sign: a msg with private key results signature.
sig = bc.ecdsa_sign(msg, pri_key)
# print(sig)
# G/F44oENphvCN9Xbnnrca1cVN762xMfRlPN3bZ/tuwzVR6F9W2DqP79aWVlM+FO/Ao0u60JK4HGLEE+5sqDv4e0=

## Verify: msg + signature + public key results a boolean.
# print(bc.ecdsa_verify(msg, sig, pub_key))
## The message receivers can verify the message + sig with public key
##   without knowning the private key.

## Try: msg is modified.
# msg = 'Hello how do you do.'
# print(bc.ecdsa_verify(msg, sig, pub_key))

## Try: non-corresponding public key
# pub_key = bc.privkey_to_pubkey(bc.random_key())
# print(bc.ecdsa_verify(msg, sig, pub_key))

#--------------------------------------------------

## If the verification sucess that means the transaction is really
#    created by Jack and had not been modified.

## Only the person who has the private key can generate the corresponding
#   public key and address.
# So a private key is the identity witness of the Bitcoin user.

## Typically, Jack creates his private key (with the help of a Wallet app).
# He create his address and reveal to John for sending Bitcoin to him.
# He uses both private key and public key to create his transaction
#   to redeem the transaction sent by John.
# Only his public key presents in the transaction.
# His private key is secretly stored until redeeming the transaction.

#---------------------------------------------------------

## Ethereum:
# EIP-191 defines signable message that is ready to be signed.
from eth_account.messages import encode_defunct
from eth_utils.curried import to_hex, to_bytes

def signable_msg():
    msg = "hello"       # Try:   msg = "สวัสดี"
    sm = encode_defunct(text=msg)
    print(sm.body)          # b'hello'
    print(sm.body.decode()) # hello
    print(to_hex(sm.body))  # 0x68656c6c6f
# signable_msg()

# Sign with private key:
from eth_account import Account
def sign_verify():
    # Account of the signer.
    a = Account.create('john')
    print(a.address)

    # Message to be signed.
    msg = 'Hello who are you today?'
    signable_msg = encode_defunct(text=msg)

    # Sign message with the signer's private key
    signed_msg = Account.sign_message(signable_msg, a.key)
    print(signed_msg)

    # Signature:
    sig = signed_msg.signature
    print(to_hex(sig))

    # Recover the signer address.
    ac = Account.recover_message(signable_msg, signature=sig)
    print(ac)

    # Verify if the message is signed by the address?
    print(a.address == ac)

    # Alternatively we can recover the signer address
    #  from its message hash instead of the message.
    # A signed message also contains its message hash
    #  which is using less space than the message.
    msg_hash = signed_msg.messageHash
    print(to_hex(msg_hash))
    ac = Account.recoverHash(msg_hash, signature=sig)
    print(ac)
# sign_verify()
