from myutil import *

# Infura does not provide 'wallet'.
def infura():
    print(w3i.clientVersion) # Geth ....
    print(w3i.eth.chainId)   # 4
    print(w3i.eth.mining)    # False
    print(w3i.eth.get_block('latest').number)  # ...
    print(w3i.eth.accounts)  # []
infura()

## Geth, Openethereum and Anvil performs 'wallet' function.
def wallet():
    print(w3.clientVersion)
    print(w3.eth.accounts)       # ....
# wallet()
