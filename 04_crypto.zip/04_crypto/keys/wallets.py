from web3 import Web3
# Infura does not provide 'wallet'.
def infura():
    URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
    w3i = Web3(Web3.HTTPProvider(URL))
    from web3.middleware import geth_poa_middleware
    w3i.middleware_onion.inject(geth_poa_middleware, layer=0)

    print(w3i.clientVersion) # Geth ....
    print(w3i.eth.chainId)   # 4
    print(w3i.eth.mining)    # False
    print(w3i.eth.get_block('latest').number)  # ...
    print(w3i.eth.accounts)  # []
infura()

## Anvil performs 'wallet' function.
def anvil():
    w3a = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

    print(w3a.clientVersion)      # anvil/v0.1.0
    print(w3a.eth.chainId)        # 31337
    print(w3a.eth.get_block('latest').number)  # 0
    print(w3a.eth.accounts)       # ....
# anvil()
