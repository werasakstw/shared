import os
from eth_keys import keys
from eth_utils import keccak, decode_hex
def gen_prikeys():
    # Create a random private key.
    pri_key = keys.PrivateKey(os.urandom(32)) # 32 bytes string.
    print(pri_key)

    # Create a private key from a seed.
    seed = 'Hello how are you?'
    pri_key = keys.PrivateKey(keccak(seed.encode()))
    print(pri_key)

    # Create a private key from a hex string. (no prefix '0x')
    pk_str = '66a80b61b29ec044d14c4c8c613e762ba1fb8eeb0c454d1ee00ed6dedaa5b5c5'
    pri_key = keys.PrivateKey(decode_hex(pk_str))
    print(pri_key)
# gen_prikeys()

def pub_addr():
    pri_key = keys.PrivateKey(os.urandom(32))
    pub_key = pri_key.public_key
    print(pub_key)
    print(pub_key.to_address())
    print(pub_key.to_checksum_address())
# pub_addr()

## OpenEthereum stores (iwa) keyfile at data dir.
data_dir = 'C:/Users/THAIMART/AppData/Roaming/OpenEthereum/keys/rinkeby/'
key_file = 'UTC--2022-06-07T03-40-09Z--c698d7b1-2c75-5d82-f25b-26789e606a07'

# Retrieving private key from keyfile.
def get_privatekey():
    with open(data_dir+key_file) as f:
        k = w3.eth.account.decrypt(f.read(), 'john')
        print(to_hex(k))
# get_privatekey()
## So iwa is not really safe.
## Using owa and protecting your private key with a password is a much better choice.

#--------------------------------------------------------

## Private keys are big, saving in a file is very helpful.
john_pri_key = '0xadbbab5c9f62b10d4bcdb3b102f29fe3fa644389e796f60155bf809cd84d9f9b'
jack_pri_key = '0x5273729e45021f0b2545678e300792381a6878e1f4de94ddb8e6fd02a8427462'

import pickle
def keyfile_test():
    d = {'john': john_pri_key, 'jack': jack_pri_key}
    ## Write to file.
    with open('key', 'wb') as f:
        pickle.dump(d, f)

    ## Read from file.
    with open('key', 'rb') as f:
        rd = pickle.load(f)
    print('john_pri_key:', rd['john'])
    print('jack_pri_key:', rd['jack'])
# keyfile_test()
