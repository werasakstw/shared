from web3 import Web3

# Infura
URLi = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3i = Web3(Web3.HTTPProvider(URLi))
from web3.middleware import geth_poa_middleware
w3i.middleware_onion.inject(geth_poa_middleware, layer=0)

# Geth, Openethereum and Anvil
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

import requests
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}
def rpc(method, param):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": %s, "id": 1}' % (method, param)
   return requests.post(URL, data=DATA, headers=HEADERS).text

def quote(w):
   return '["%s"]' % w

def quote2(w1, w2):
   return '["%s", "%s"]' % (w1, w2)

def quote3(w1, w2, w3):
   return '["%s", "%s", "%s"]' % (w1, w2, w3)

import json
def print_json_str(st):
   res_json = json.loads(st)
   print(json.dumps(res_json, indent=4, sort_keys=True))

def print_json(ad): # AttributeDict
   st = w3o.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))

def print_result(st):
   print(json.loads(st)['result'])
