import bitcoin as bc
import random

## Private key:
# 'bitcoin' lib provides a constant N for the max value of private key.
# A private keys is a non-negative interger that less than bitcoin.N.
# Normally private keys are represented as hex string.
# Bitcoin private keys are 64 hex-digits (32 bytes).
def max_prikey():
    print(bc.N)
    # 115792089237316195423570985008687907852837564279074904382605163141518161494337
    n_hex = hex(bc.N)[2:]  # exclude prefix '0x'.
    print(len(n_hex), n_hex)
    # 64 fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141
# max_prikey()

## Private key verification:
def is_valid_privkey(k):  # 'k' is an int.
    return 0 < k < bc.N

# 'bitcoin' lib provides is_privkey(), is_pubkey() and is_address().
# print(bc.is_privkey(bc.N))        # True

## Generate private keys:
seed = 'This is a seed.'
def private_key():
    # Generate private key randomly.
    for _ in range(3):
        print(hex(random.randint(1, bc.N))[2:])
    print()

    # bc.sha256(<seed>) results value with a slim chance of
    # overflow the value of bc.N. But allows repeatedly creating
    # the same values from a <seed>.
    for _ in range(3):
        print(bc.sha256(seed))
    print()

    # bc.random_key() results a random valid private key.
    for _ in range(3):
        print(bc.random_key())
# private_key()

## Compressed private key verification:
# Uncompressed private keys are 32 bytes (64 hex-digits).
# Compressed private keys are 33 bytes (66 hex-digits) and ends with '01'.
def is_compressed_privkey(k):   # 'k' is a str.
    return bc.is_privkey(k) and k.endswith('01')

# Private key encodes:
def privkey_encode():
    hex_str = bc.sha256(seed)
    print(hex_str)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # From hex string to byte array
    byte_array = bc.from_string_to_bytes(hex_str)
    print(byte_array)
    # b'517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86'

    # From hex str to (decimal)int, so that arithmetic can be performed
    dec_int = bc.decode_privkey(hex_str, 'hex')
    print(dec_int)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    # From (decimal)int to hex str.
    print(bc.encode_privkey(dec_int, 'hex'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # From (decimal)int to hex str in compressed format private key.
    print(bc.encode_privkey(dec_int, 'hex_compressed'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    # From (decimal)int to hex str in wif format private key.
    print(bc.encode_privkey(dec_int, 'wif'))
    # 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7

    # From (decimal)int to hex str in wif format compressed private key.
    print(bc.encode_privkey(dec_int, 'wif_compressed'))
    # Kyx8qCKsSbUrUxQMaQNsq4rxq23FxkfE2haXgNArX9c38qmpkmG5
# privkey_encode()

def private_key_formats():
    # Private Key(hex)
    hex_pri = bc.sha256(seed)   # bc.random_key()
    print(hex_pri)

    # Private Key(dec)
    dec_pri = bc.decode_privkey(hex_pri, 'hex')
    print(dec_pri)

    # Private Key(wif) base58, 51 chars and starts with '5'.
    print(bc.encode_privkey(dec_pri, 'wif'))

    # Compressed Private Key(hex)
    comp_hex_pri = hex_pri + '01'
    print(comp_hex_pri)

    # Compressed Private Key(wif) base58, 52 chars and starts with 'K' or 'L'.
    comp_wif_pri = bc.encode_privkey(bc.decode_privkey(comp_hex_pri, 'hex'), 'wif')
    print(comp_wif_pri)
# private_key_formats()

#---------------------------------------------------------------

# G is a constant point(x, y) on Elliptic Curve, represented as a tuple.
# print(bc.G)

## Public Keys: All private key has its corresponding public key.
# A public key can be quickly computed from its corresponding private key.
# But the reverse is not feasible.
# Mathematically a public key is computed by:
#           <public key>  is  G * <private key>
# where * is the 'fast multiply', not a normal mutiplication.
# Bitcoin public keys 130 hex-digits (65 bytes).
def public_key():
    # Generate a private key from a seed.
    hex_priv = bc.sha256(seed)
    print(hex_priv)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # Decoded hex private key to decimal.
    dec_priv = bc.decode_privkey(hex_priv, 'hex')
    print(dec_priv)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    # Public Key Point (x,y) on Elliptic Curve of equation:
    #               y**2 mod p = (x**3 + 7) mod p
    # fast_multiply() is EC multiply (with G).
    pub_point = bc.fast_multiply(bc.G, dec_priv)
    print(pub_point)   # tuple of x and y.
    # (72586088254300629282474542646364941725084793931958144488404839039713232267068, 84543921150964833926999570811767834131266370888940557583189318793530522725677)

    # Public Key is the Public Key Point (x,y) encoded to hex.
    # Encode decimal private key to hex string.
    hex_pub = bc.encode_pubkey(pub_point, 'hex')
    print(hex_pub)
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d

    # 'bitcoin' lib provides functions to compute public key from private key.
    print(bc.privkey_to_pubkey(hex_priv))   # Alternatively: bc.privtopub()
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d
# public_key()
## Try: changing the seed. Bitcoin public keys are prefixed with '04'.
## Check with:   bitaddress.org

## Key Compreesion:
# Public keys are too big.
# Since the Elliptic Curve function: y**2 mod p = (x**3 + 7) mod p
# is known, the x or y part of a point(x, y) can be computed if the other
# part is known. The left side of the equation is y**2 so y may be positive
# or negative depended on y is even or odd.
# A prefix is used to indicate whether y is even or odd.
def compressed_pubkey():
    hex_priv = bc.sha256(seed)
    dec_priv = bc.decode_privkey(hex_priv, 'hex')
    x, y = bc.fast_multiply(bc.G, dec_priv)
    prefix = '02' if (y % 2) == 0 else '03'
    # Compressed Public Key(hex) is prefix + hex(x)
    print(prefix + bc.encode(x, 16))
    # 03a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73c
# compressed_pubkey()

# So we can store only the x part of a public key, which is called compressed
# public keys that use less space and thus reduce the size of transactions.
# Normally uncompressed public keys are used internally e.g. to create a tx
#  and verify an address.

# But we need a way to distinguish the compresses and un-compressed versions.
def compressed():
    # Uncompressed private key:
    pri_key = bc.sha256(seed)
    print(pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # Compressed private key:
    # Adding '01' suffix to indicate it is a compressed private key.
    comp_pri_key = pri_key + '01'
    print(comp_pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    # Uncompressed public key: computed from uncompressed private key.
    pub_key = bc.privkey_to_pubkey(pri_key)
    print(pub_key)
    # 04a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73cbaea29e35d294c23fee4db6f8acbb7fcf66418dc24c8e8a624778114a7b3ed2d

    # Compressed public key: computed from compressed private key.
    comp_pub_key = bc.privkey_to_pubkey(comp_pri_key)
    print(comp_pub_key)
    # 03a07a45221269467e33bee642d7aef559abff0c26855d1bae712697188677a73c
# compressed()

## Address:
# Even compressed version, public keys are big.
# An address can be computed from the corresponding private key or public key.
def addresses():
    pri_key = bc.sha256(seed)
    comp_pri_key = pri_key + '01'

    addr = bc.privkey_to_address(pri_key)
    comp_addr = bc.privkey_to_address(comp_pri_key)
    print(addr)         # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2
    print(comp_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA

    # There is also bc.pubkey_to_address().
    pub_key = bc.privkey_to_pubkey(pri_key)
    comp_pub_key = bc.privkey_to_pubkey(comp_pri_key)
    addr = bc.pubkey_to_address(pub_key)
    comp_addr = bc.pubkey_to_address(comp_pub_key)
    print(addr)         # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2
    print(comp_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA
# addresses()

## Private key and Address encode.
def encodes():
    pri_key = bc.sha256(seed) # hex str
    print(pri_key)
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86

    # from hex string to byte array
    ba_pri_key = bc.from_string_to_bytes(pri_key)
    print(ba_pri_key)
    # b'517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86'

    # from hex string to int (binary but presented as decimal)
    # so that arithmetic can be performed.
    int_pri_key = bc.decode_privkey(pri_key, 'hex')
    print(int_pri_key)
    # 36863404501039226994932749640652428376780269686920716174806313085065835281030

    ## encoded private key from int
    print(bc.encode_privkey(int_pri_key, 'hex'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a86
    print(bc.encode_privkey(int_pri_key, 'hex_compressed'))
    # 517ff2931af6f4b473b329e716cb04380b1066ab3d22a5d324203acd472f7a8601

    wif_prikey = bc.encode_privkey(int_pri_key, 'wif')
    print(wif_prikey)
    # 5JSBPFM8oae88hCBZ38DsmNk1TWxxE4gCiNC2fnHCpGBuZTEgb7

    comp_wif_prikey = bc.encode_privkey(int_pri_key, 'wif_compressed')
    print(comp_wif_prikey)
    # Kyx8qCKsSbUrUxQMaQNsq4rxq23FxkfE2haXgNArX9c38qmpkmG5

    # wif address from private key
    wif_addr = bc.privkey_to_address(wif_prikey)
    print(wif_addr)    # 1ECj6v1pWq1KdeZhf6997vWb55b5abzjt2

    comp_wif_addr = bc.privkey_to_address(comp_wif_prikey)
    print(comp_wif_addr)    # 1EZimPwq7eCFziRyuZSDzqKam1WxugiXaA
# encodes()

#------------------------------------------------------

## To verify fund receiver:
# Suppose John send a transaction transfers BTC to Jack.
# The transaction specifies the fund receiver by Jack address.
# To redeem the transaction Jack must create a transaction that
#   contains his public key to indicate that he is rightful receiver.

## To verify that a public key is the valid reciver of an address:
def is_valid_receiver(pubkey, addr):
    return addr == bc.pubkey_to_address(pubkey)
