# pip install eth_account
# pip install eth_utils
from eth_account import Account
from eth_utils.curried import to_hex

# Creating enthereum account: (off-line)
# The account is off-wallet, no providers needed and always return a new account.
# Off wallet accounts(owa) are not stored in the wallet.
# An enthereum account contains _private_key and address, but no _public_key.
def create_account():
    a = Account.create('This is a seed.')
    print(to_hex(a._private_key))
    print(a.address)        # checksum address
# create_account()

## To compute public key and address from private key:
# pip install eth-keys
from eth_keys import keys
from eth_utils import decode_hex
def gen_keys():
    pri_key_hex_bytes = Account.create()._private_key   # hex bytes
    pri_key = to_hex(pri_key_hex_bytes)     # hex str
    print(pri_key)

    # Private key -> Public key:
    pri_key_bytes = decode_hex(pri_key)
    pri_key_obj = keys.PrivateKey(pri_key_bytes) # private key object
    pub_key = pri_key_obj.public_key
    print(pub_key)

    # Public key -> Address:
    print(pub_key.to_address())
    print(pub_key.to_checksum_address())
# gen_keys()
## Check: eth_util.py for what is checksum address?

#------------------------------------------------------

# Most enthereum nodes e.g. infura, Geth and Openethereum
# provide service for creating owa.
from myutil import *
def offwallet_account():
    a = w3.eth.account.create('This is a seed.')
    # a = w3o.eth.account.create('This is a seed.')

    print(to_hex(a._private_key))
    print(a._address)

    print(w3.eth.accounts)         # []
    # print(w3o.eth.accounts)
# offwallet_account()

## In wallet account(iwa) is stored in the wallet.
## Openethereum allows creating iwa with geth.personal.new_account(<pwd>).
# print(w3o.geth.personal.new_account('john'))
# print(w3o.eth.accounts)

## Try: json_rpc to Openethereum.
# print(rpc('eth_accounts', []))

# Account addresses are used for send transactions to and
# check balances.
def get_me_balance():  # 'me' account from metamask.
    me_addr = '0x16c25A4cb42906a367Cce89043f3e39F9f892eb0'
    print(w3.eth.get_balance(me_addr))
    print(w3o.eth.get_balance(me_addr)) # Openethereum must complete syncing.
# get_me_balance()

#---------------------------------------------------------------

## Account creating via rpc is discourage.
## But Parity(fromer name of Openethereum) supports json_rpc for account managing.

## Create an iwa. The recovery phrase must be unique.
# print(rpc('parity_newAccountFromPhrase', quote2('recovery phrase1', 'jack')))
# print(rpc('parity_newAccountFromPhrase', quote2('recovery phrase2', 'joe')))

## List accounts with info.
# print_json_str(rpc('parity_allAccountsInfo', []))
# print(w3o.eth.accounts)
john_addr = '0x286d11a733ae3c67d7a7b04a438b967abb7a466d'
jack_addr = '0x000a9727ddfe97e01769ac4c1f8e338a1c7c4c1d'

## Verify address with password.
# print_result(rpc('parity_testPassword', quote2(john_addr, 'john')))

## Change password.
old_pwd = 'john'
new_pwd = 'John'
# print_result(rpc('parity_changePassword', quote3(john_addr, old_pwd, new_pwd)))
# print_result(rpc('parity_testPassword', quote2(john_addr, 'john')))
# print_result(rpc('parity_testPassword', quote2(john_addr, 'John')))

# Set account name.
# print_json_str(rpc('parity_setAccountName', quote2(jack_addr, 'Ripper')))
# print_json_str(rpc('parity_allAccountsInfo', []))

# Set account meta (as a json).
params = '''[\"0x00d6ffa36000c6d01577ab1954e6d4040e20a5bb\", \  # john_addr
\"{\\"aliases\\":\\"First Blood\\"}\" ]'''
# print_json(rpc('parity_setAccountMeta', params))
# print_json_str(rpc('parity_allAccountsInfo', []))

## Kill an account.
# print_json_str(rpc('parity_killAccount', quote2(john_addr, new_pwd)))
# print(rpc('parity_allAccountsInfo', []))
