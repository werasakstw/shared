## Tamper: is any actions to modify (including append and delete) data.
## Tamper Proof: is a verification that data had been tamperred or not.

import bitcoin as bc
from myutil import *

def gen_hash(file_name, hash_file):
    msg = read_file(file_name)
    write_file(hash_file, bc.sha256(msg))
# gen_hash('hello.txt', 'myhash')

def verify_hash(file_name, hash_file):
    msg = read_file(file_name)
    hash = read_file(hash_file)
    if hash == bc.sha256(msg):
        print('Valid')
    else:
        print('Invalid')
# verify_hash('hello.txt', 'myhash')

## Try: Modify hello.txt.
