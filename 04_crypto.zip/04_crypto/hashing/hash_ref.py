import bitcoin as bc

## Hash References:
# Python dict stores items as <key>:<value>.
d = { }         ## an empty dict

# Storing a value with its hash as the key.
value = 'Hello'
key = bc.sha256(value)
d[key] = value

# Get value by key using index [] results KeyError if the key is not found.
print(d[key])             #  Hello

## Try: If the value is modified.
# d[key] = 'Hello!'
## We can verify that the value is invalid.
# print(key == bc.sha256(d[key]))

## Try: If the key is modified.
# key = bc.sha256("What's up?")
## We can verify that the key is invalid.
# print(d[key])             # KeyError:
