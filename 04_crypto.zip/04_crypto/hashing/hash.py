## pip install pybitcoin

import hashlib as hl     ## A standard Python's lib
import bitcoin as bc
# print(hl.algorithms_available)

msg = 'Hello! how are you today?'
def simple_hash():
    ## Md5: (16 bytes)
    md5 = hl.md5(msg.encode())      ## Md5 hashed object
    md5_str = md5.hexdigest()       ## str
    print(len(md5_str), '\t', md5_str)    ## 32 chars (16 bytes)

    ## Sha1: (20 bytes)
    sha1 = hl.sha1(msg.encode())
    sha1_str = sha1.hexdigest()
    print(len(sha1_str), '\t', sha1_str)  ## 40 chars (20 bytes)
# simple_hash()

## Bitcoin uses Sha256: 64 chars (32 bytes)
def bc_hash():
    sha256 = hl.sha256(msg.encode())
    sha256_str = sha256.hexdigest()
    print(len(sha256_str), sha256_str)

    ## 'bitcoin' Python lib provides an easy to used hash functions.
    bc_sha256 = bc.sha256(msg)
    print(len(bc_sha256), bc_sha256)
# bc_hash()

#----------------------------------------------

# Ethereum uses Keccak-256 hashing.

## pip install eth-keys
from eth_utils import keccak, encode_hex
def eth_keccak():
    me = keccak(msg.encode())   # byte array
    print(encode_hex(me))
    # 0x1613f1e3375bc66e4a4f79f174bee9adcc54312c206b8a9ba3fc4a06d58dcfe6

    ## keccak != sha3_256
    print(hl.sha3_256(msg.encode()).hexdigest())
    # a03313c1383024b4dc1997a7ed4e9ef47e805953f7bd8a35d18c04d7280fb958
# eth_keccak()
