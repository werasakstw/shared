# 'nonce' is an integer to be included in the block.
# Mining is the process of finding a 'nonce' such that
#  the block hash has the number of preceeding zeros
#  more than a certain value, defined by 'diff'.

import bitcoin as bc
def mine(diff):
    # Suppose a block is just a string.
    block = 'Hello how do you do?'
    target = '0'*diff     # A string of diff zeros.
    nonce = 0
    while True:
        # Suppose 'nonce' is just appended to a block.
        h = bc.sha256(block + str(nonce))
        if h.startswith(target):
            print('%d:\t%d\t%s' % (diff, nonce, h))
            break
        nonce += 1

for i in range(1, 5):
    mine(i)
