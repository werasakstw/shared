## A Poorman Blcokchain:
# A block is a str of name.
# A blockchain is implemented as a dict.
# A dict item is a list of [<previous_hash>, <block>]

# Initially the blockchain is empty.
dic = { }

# Block ids (hash) are stored in a list.
ids = []

def last_block():
    return None if ids == [] else ids[len(ids)-1]

def print_blockchain():
    for i in dic:
        print(i, dic[i])
    print('last_block:', i)

import bitcoin as bc
def add_blocks():
    data0 = 'John'
    id0 = bc.sha256(data0)
    dic[id0] = [None, data0]   # genesis block
    ids.append(id0)

    data1 = 'Jack'
    id1 = bc.sha256(data1)
    dic[id1] = [id0, data1]
    ids.append(id1)

    data2 = 'Joe'
    id2 = bc.sha256(data2)
    dic[id2] = [id1, data2]
    ids.append(id2)
add_blocks()
# print_blockchain()

def verify_blockchain():
    i = last_block()
    if i != bc.sha256(dic[i][1]):
        print('last block error')
        return
    while i != None:
        previous_hash = dic[i][0]
        if previous_hash != None and \
           previous_hash != bc.sha256(dic[previous_hash][1]):
            print('link error')
            return
        i = dic[i][0]
    print('valid')
# verify_blockchain()

# Modify the last block (Joe).
def test():
    lb = last_block()
    dic[lb][1] = 'joe'

    ## But it is possible to replace the last block and the last_block variable.
    # data = 'jame'
    # id_ = bc.sha256(data)
    # previous_hash = dic[lb][0]
    # dic[id_] = [previous_hash, data]
    # ids[len(ids)-1] = id_

    print_blockchain()
    verify_blockchain()
# test()

## Exercise: Modify the Jack block.
## Blocks should have created timestamp to make modifying the Blockchain more difficult.
