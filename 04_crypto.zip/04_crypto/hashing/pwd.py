
## Redis is a simple name server, that allows saveing <name>:<value> items.

# pip install redis
import redis
rd = redis.Redis() # host='localhost', port=6379, db=0,
                   # password=None, socket_timeout=None,...
# print(rd.ping())

import bitcoin as bc
def register(name, pwd):
    rd.set(name, bc.sha256(pwd))
# register('john', 'john123')
# register('jack', 'jack123')

def verify(name, pwd):
    return rd.get(name).decode() == bc.sha256(pwd)
# print(verify('john', 'john123'))
# print(verify('jack', 'jack123'))
