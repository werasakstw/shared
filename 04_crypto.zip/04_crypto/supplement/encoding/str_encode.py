''' Most programs handle data by bytes or characters.
Python str is a sequence of Unicode characters,
A Unicode character may be one to four bytes.
'''
s1 = 'ABC'
s2 = 'กขค'
def str_iterate():
    # len() returns number of characters, not bytes.
    print(len(s1), len(s2))     # 3 3

    # By default, strs are iterated by character.
    for c in s1:
        print(c, end=',')       # A,B,C,
    print()

    for c in s2:
        print(c, end=',')       # ก,ข,ค,
# str_iterate()

##  <str>.encode()  converts str to bytes (byte array).
##  <str>.decode()  converts bytes to str.
def enc_dec():
    se = s1.encode()
    print(se)           # b'ABC'    (Bytes literals)
    print(se.decode())  # ABC

    ## Bytes are iteratred by bytes.
    for c in s1.encode():       ## 65,66,67,
        print(c, end=',')
    print()
    for c in s2.encode():
        print(c, end=',')       ## 224,184,129,224,184,130,224,184,132,
# enc_dec()

''' A plain English string is represented as ASCII codes of Unicodes
which is 7 bits of a byte. '''

data = 'Hello'      # 5 bytes(characters).
def binary():
    # int -> binary
    print(bin(3))           # 0b11
    # Binary base int literals begin with '0b'.

    # Python does not support 'char' type, but single character str.
    # ord(<character>) returns Unicode value(as int) of the character.
    print(ord('A'))         # 65
    # char -> binary
    print(bin(ord('A')))    # 0b1000001
# binary()
