''' Keys and addreses are very big values.
We need value encodings easily handled by human.
Whatever encodings they must represent the same value.
'''
## Binary Encoding: (0-1) Too many digits.
data = 'Hello'
def bin_encode():
    ## Convert each byte to binary.
    a = [bin(x)[2:] for x in data.encode()] # exclude '0b' prefix
    print(a)    # ['1001000', '1100101', '1101100', '1101100', '1101111']
    print(''.join(a)) # 10010001100101110110011011001101111
# bin_encode()

## Decimal: (0-9) A byte may be two or three digits.
# If no separator, we cannot decode back to original data.
def dec_encode():
    a = [str(ord(x)) for x in data]
    print(a)            # ['72', '101', '108', '108', '111']
    print(''.join(a))   # 72101108108111
# dec_encode()

## Hexadecimal: (0-9 and a-f) All bytes are two hex digits.
def hex_encode():
    a = [hex(ord(x))[2:] for x in data]   # exclude '0x' prefix
    print(a)            # ['48', '65', '6c', '6c', '6f']
    print(''.join(a))   # 48656c6c6f

    ## str -> hex_str
    # hex() encodes bytes to hex_string.
    h = data.encode().hex()
    print(h)             # 48656c6c6f

    # hex_str -> str
    s = bytes.fromhex(h).decode()
    print(s)             # Hello
# hex_encode()

## Base64:  (a-z, A-Z, 0-9, =, /)
# Using more symbols, resulting shorter result than equivalent hexadecimal.
# Commonly used for attachment in emails (not handled by human).
import base64
def base64_encode():
    b64 = base64.b64encode(data.encode())
    print(b64.decode())                     # SGVsbG8=
    print(base64.b64decode(b64).decode())   # Hello
# base64_encode()

## Base58: (base64, exclude 0, o, O, I, =, /)
# Less error prone but may be slightly longer than equivalent base64.
# More suitable to human than base64.
# pip install base58
import base58
def base58_encode():
    b58 = base58.b58encode(data)    # accepts str, returns bytes.
    print(b58.decode())                     # 9Ajdvzr
    print(base58.b58decode(b58).decode())   # Hello
# base58_encode()

## Base58Check(WIF): (base58 + Checksum)
# WIF is Wallets Imported Format. Suitable to human and allows error-checking.
# Prefix with version code and suffix with checksum then encoded with base85.
def base58check_encode():
   b58c = base58.b58encode_check(data)
   print(b58c.decode())                         # vSxRbq6XzDhP
   print(base58.b58decode_check(b58c).decode()) # Hello
# base58check_encode()
