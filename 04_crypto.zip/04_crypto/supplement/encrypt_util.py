from eth_account import Account
from eth_utils.curried import to_hex, to_bytes
import pprint as pp

# Instead of encrypt account manually, Account provides encrypt().
def encrypt_account():
    john_acc = Account.create('john')  # 'john' is not the account password.
    print(to_hex(john_acc.key))
    print(john_acc.address)

    # Encrypt an account to a json(dict).
    enc_john_acc = john_acc.encrypt('hello')   # 'hello' is the encrypt password.
##    pp.pprint(enc_john_acc)

    # Decrypt an encrypted account to private key
    john_prikey = Account.decrypt(enc_john_acc, 'hello')
    print(to_hex(john_prikey))

    # Retrieve account from private key.
    ja = Account.from_key(john_prikey)
    print(ja.address)
# encrypt_account()

# Encrypt private keys with password.
def encrypt_prikey():
    john_acc = Account.create('john')
    john_prikey = john_acc.key
    print(to_hex(john_prikey))

    # Encrypt private key with a password.
    en_john_prikey = Account.encrypt(john_prikey, 'rambo')
##    pp.pprint(en_john_prikey)

    # Decrypt the encrypted private key with the password.
    pri = Account.decrypt(en_john_prikey, 'rambo')
    print(to_hex(pri))
# encrypt_prikey()

## BIP39: defines a list of words for password.
def mnemonic():
    # Enable HD wallet
    Account.enable_unaudited_hdwallet_features()

    # Create an account with mnemonic.
    acc, mm = Account.create_with_mnemonic()
    print(acc.address)
    print(mm)

    # Retrieve an account from mnemonic.
    print(Account.from_mnemonic(mm).address)
mnemonic()
