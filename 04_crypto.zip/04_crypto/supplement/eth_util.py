// https://pypi.org/project/eth-utils/1.1.2/

from eth_utils import *
# Ethereum addresses:
unpad =   'd3cda913deb6f67967b99d67acdfa1712c293601'
lower = '0xd3cda913deb6f67967b99d67acdfa1712c293601'
upper = '0xD3CDA913DEB6F67967B99D67ACDFA1712C293601'
chsum   = '0xd3CdA913deB6f67967B99D67aCDFa1712C293601'
def valid_test():
    # 20 byte hexadecimal, lower/upper/mixed case,
    #  with or without 0x prefix.
    # print(is_address(unpad), is_hex_address(unpad)) # True True
    # print(is_address(lower), is_hex_address(lower)) # True True
    # print(is_address(upper), is_hex_address(upper)) # True True
    # print(is_address(chsum), is_hex_address(chsum)) # True True
    #
    # # Checksummed address: ERC55
    # print(is_checksum_address(unpad), is_checksum_formatted_address(unpad)) # False False
    # print(is_checksum_address(lower), is_checksum_formatted_address(lower)) # False False
    # print(is_checksum_address(upper), is_checksum_formatted_address(upper)) # False False
    # print(is_checksum_address(chsum), is_checksum_formatted_address(chsum)) # True False

    # Normalized addresses are lowercased.
    print(is_normalized_address(lower))    # True
    print(is_normalized_address(upper))    # False
    print(is_normalized_address(chsum))    # False

    # True if both are valid by is_address() and represent the same.
    print(is_same_address(unpad, chsum))    # True
    print(is_same_address(lower, chsum))    # True
    print(is_same_address(upper, chsum))    # True
# valid_test()

def converse_address():
    # Canonical addresses are arrays of bytes, that exactly be handled by programs.
    print(to_canonical_address(unpad))  # b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'
    print(to_canonical_address(lower))
    print(to_canonical_address(upper))
    print(to_canonical_address(chsum))

    print(to_checksum_address(unpad))   # 0xd3CdA913deB6f67967B99D67aCDFa1712C293601
    print(to_checksum_address(lower))
    print(to_checksum_address(upper))
    print(to_checksum_address(chsum))
    print(to_checksum_address(b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'))

    print(to_normalized_address(unpad))   # 0xd3cda913deb6f67967b99d67acdfa1712c293601
    print(to_normalized_address(lower))
    print(to_normalized_address(upper))
    print(to_normalized_address(chsum))
    print(to_normalized_address(b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'))
# converse_address()

# Conversion for standard representation in the Ethereum ecosystem.
def converse_unit():
    # to_bytes(<int/bool/bytes>, text=<str>, hexstr=<str>) -> bytes  (byte array)
    print(to_bytes(0), to_bytes(1), to_bytes(0xF))   # b'\x00' b'\x01' b'\x0f'
    print(to_bytes(True), to_bytes(False))           # b'\x01' b'\x00'
    print(to_bytes(b''), to_bytes('hello'.encode())) # b'' b'hello'

    # Python cannot distinguish between string and a hex-encoded bytestring.
    print(to_bytes(text='hello'), to_bytes(text='กข'))
                # b'hello' b'\xe0\xb8\x81\xe0\xb8\x82'
    addr = '0xd3CdA913deB6f67967B99D67aCDFa1712C293601'
    print(to_bytes(hexstr=addr))
        # b'\xd3\xcd\xa9\x13\xde\xb6\xf6yg\xb9\x9dg\xac\xdf\xa1q,)6\x01'
#--------------------------------------------------------------------------

    # to_hex(<int/bool/bytes>, text=<str>, hexstr=<str>) -> str (hex string)
    print(to_hex(0), to_hex(1), to_hex(0xF))     # 0x0 0x1 0xf
    print(to_hex(True), to_hex(False))           # 0x1 0x0
    print(to_hex(b''), to_hex('hello'.encode())) # 0x 0x68656c6c6f
    print(to_hex(text=''), to_hex(text='hello')) # 0x 0x68656c6c6f
    print(to_hex(hexstr='000f'))                 # 0x000f

#--------------------------------------------------------------------------

    # to_int(<bytes/int/bool>, text=<str>, hexstr=<str>) -> int
    print(to_int(0), to_int(1), to_int(0xF))     # 0 1 15
    print(to_int(True), to_int(False))           # 1 0
    print(to_int(b''), to_int('hello'.encode())) # 0 448378203247
    # print(to_int(text='hello'))       # error
    print(to_int(hexstr='000f'))        # 15

    # to_text(<int/bytes>, text=<str>, hexstr=<str>) -> str
    print(to_text(0), to_text(1), to_text(0xF))    # <empty> <binary> <binary>
    print(to_text(448378203247))                   # hello
    # print(to_text(True), to_text(False))         # error
    print(to_text(b''), to_text('hello'.encode())) # <empty> hello
# converse_unit()

def hashing():
    print(keccak(text=''))      # b"\xc5\xd2F\x01\x86\xf7#<\x92~}\xb2\xdc\xc7\x03\xc0\xe5\x00\xb6S\xca\x82';{\xfa\xd8\x04]\x85\xa4p"
    print(keccak(448378203247)) # b"\x1c\x8a\xff\x95\x06\x85\xc2\xedK\xc3\x17O4r({V\xd9Q{\x9c\x94\x81'1\x9a\t\xa7\xa3m\xea\xc8"
    print(keccak(0x68656c6c6f))
    print(keccak('hello'.encode()))
    print(keccak(text='hello'))
    print(keccak(hexstr='0x68656c6c6f'))

    # Python truncates leading 0 of all int including hex int.
    # Hex literals maintain zeros on the left and may be aero padded to the needed length.
    print(keccak(0x1234))          # b'VW\r\xe2\x87\xd7<\xd1\xcb`\x92\xbb\x8f\xde\xe6\x179t\x95_\xde\xf3E\xaeW\x9e\xe9\xf4u\xeat2'                # True
    print(keccak(0x01234))         # b'VW\r\xe2\x87\xd7<\xd1\xcb`\x92\xbb\x8f\xde\xe6\x179t\x95_\xde\xf3E\xaeW\x9e\xe9\xf4u\xeat2'
    print(keccak(hexstr='0x1224')) # b'_\x1d\x11X!\x1d\xa4\xc0\xa7C\x92\x96\x0c\x1djX\xfc4\xd5=\xbe;\xbe]\x1d\xaf\x85\x9a\xd3\xf3\xf2\xa1'
    print(keccak(hexstr='0x01234'))# b'\xa3\xe1\xb4\xde >\x0e]\x02 ]h\x04\x859\x07\x11\xefX\xbcL6\x87\xb1rw\xb6/\xde\x10\xa4]'
# hashing()

def currency():
    # # to_wei(value, denomination) -> integer
    # print(to_wei(1, 'ether'))   # 1000000000000000000
    # print(to_wei(1, 'kether'))  # 1000000000000000000000
    # print(to_wei(1, 'mether'))  # 1000000000000000000000000
    # print(to_wei(1, 'gether'))  # 1000000000000000000000000000
    #
    # # from_wei(value, denomination) -> decimal.Decimal
    # print(from_wei(1000000000000000000, 'ether'))   # 1
    # print(from_wei(123456789, 'ether'))             # 1.23456789E-10
    #
    # # Built-in units.
    # print(denoms.wei)           # 1
    # print(denoms.kwei)          # 1000
    # print(denoms.mwei)          # 1000000
    # print(denoms.gwei)          # 1000000000
    #
    # print(denoms.picoether)     # 1000000
    # print(denoms.nanoether)     # 1000000000
    # print(denoms.microether)    # 1000000000000
    # print(denoms.milliether)    # 1000000000000000
    # print(denoms.ether)         # 1000000000000000000
    # print(denoms.kether)        # 1000000000000000000000
    # print(denoms.mether)          # 1000000000000000000000000
    # print(denoms.gether)          # 1000000000000000000000000000
    # print(denoms.tether)          # 1000000000000000000000000000000

    # print(denoms.grand)         # 1000000000000000000000 (kether)
    # print(denoms.finney)        # 1000000000000000 (milliether, milli)
    # print(denoms.szabo)         # 1000000000000 (microether)
    # print(denoms.shannon)       # 1000000000    (gwei, nano, nanoether)
    # print(denoms.lovelace)      # 1000000       (picoether)
    # print(denoms.babbage)       # 1000          (kwei, femtoether)
    #
    print(denoms.grand == denoms.kether)
# currency()
